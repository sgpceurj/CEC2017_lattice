//
//  GPP.hpp
//  ConstrainedEDAforGPP
//
//  Created by Josu Ceberio Uribe on 02/11/16.
//  Copyright © 2016 University of the Basque Country. All rights reserved.
//

#ifndef GPP_hpp
#define GPP_hpp
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
using std::cout;
using std::endl;

class GPP
{
    
public:
    
    // The type of the instance of GPP: 0, 1, 10 or 11.
    int m_type;
    
    // The number of vertex of the graph.
    long m_vertex_num;

    // The number of edges of the graph.
    long m_edges_num;
    
    // The graph structure.
    int ** m_graph_structure;

    // Edge weights.
    int ** m_edge_weights;
    
   	// Class constructor.
    GPP();
    
    // Class destructor.
    virtual ~GPP();
    
    // Read GPP instance from file.
    long Read(char filename[]);
    
    // Create a random GPP instance.
    long Random(int size);
    
    // This function calculates the score of the given solution for the GPP instance.
    long Evaluate(int * solution);
    
    
private:
    
};

#endif /* GPP_hpp */
