//
//  main.cpp
//  ConstrainedEDAforGPP
//
//  Created by Josu Ceberio Uribe on 02/11/16.
//  Copyright © 2016 University of the Basque Country. All rights reserved.
//
#include <sys/time.h>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include "GPP.hpp"
#include "ParameterSetting.h"
#include "Individual.h"
#include "Population.h"
#include <math.h>
#include <list>
#include <string.h>
#include <limits.h>
#include <sstream>

/*
 * Generates a random binary solution of size 'n' in the given array with equal number of 0s and 1s.
 */
void GenerateRandomBinaryBalanced(int * solution, long n);

/*
 * Generates a random permutation of size 'n' in the given array.
 */
void GenerateRandomPermutation(int * permutation, int n);

/*
 * Given a population of solutions, it calculates the parameters of the probabilistic model.
 */
void Learn(CPopulation * pop, int num_solutions_to_learn);

/*
 * Samples new solutions from the initial probabilistic model.
 */
int Sample_Initial(CPopulation * pop, int num_samples);

/*
 * Samples new solutions from the probabilistic model.
 */
int Sample(CPopulation * pop, int num_samples);

/*
 * Prints in the standard output the 'size' elements of the given array..
 */
void PrintArray(int * array, long size);

/*
 * Prints in the standard output the 'size' elements of the given array..
 */
void PrintArray(float * array, long size);

/*
 * Prints in the standard output the 'size' elements of the given array..
 */
void PrintArray(long double * array, long size);

/*
 * Prints in the standard output given matrix.
 */
void PrintMatrix(long** matrix, long length, int length2);

/*
 * Prints in the standard output given matrix.
 */
void PrintMatrix(float** matrix, long length, int length2);
/*
 * Prints in the standard output given matrix.
 */
void PrintMatrix(double** matrix, long length, int length2);
/*
 * Prints in the standard output given matrix.
 */
void PrintMatrix(long double** matrix, long length, int length2);

/*
 * Initializes the order of variables in the model
 */
void Initialize_Order();

/*
 * Stores the order of the items that have been considered in the Constructive algorithm called Greedy GGP.
 */
void GreedyGraphGrowingPartitioning(int * order,long size, int iterations);

/*
 * Returns the vertex with the minimum total gain from the non_assigned_vertices.
 */
int MinimumTotalGain_Vertex(list<int> partition_of_interest,list<int> other_partition,  list<int> non_assigned_vertices);

/*
 * It determines if the given int sequecen if it is indeed a permutation or not.
 */
bool isPermutation(int * permutation, long size);

/*
 * Calculates the entry value of the variables based on the solutions in the population.
 */
void CalculateEntropyVectorOfPopulationVariables(long double * entropy);

/*
 * Calculates the pyramidal order of the values according to the vector of doubles.
 */
void GetPyramidalOrder( int * a, long double * criteriaValues, int size);

/*
 * Calculates the pyramidal order of the values according to the vector of doubles. Ties are broken randomly.
 */
void GetPyramidalOrder_Randomness( int * a, long double * criteriaValues, int size);

/*
 * Calculate the Hamming distance between two solutions A and B.
 */
int Distance(int * solutionA,int * solutionB);

void Initialize_Lattice_Uniformly();
void Initialize_Lattice_WithSolution(int * solution);
/*
 * Main function.
 */
int main(int argc, char * argv[]) {
    
    //0. Initial timing.
    struct timeval tim;
    gettimeofday(&tim, NULL);
    double t1=tim.tv_sec+(tim.tv_usec/1000000.0);
    
    // ==================================================================================
    //1. Read the parameters
    if (VERBOSE)
        cout<<"1. Reading the parameters..."<<endl;
    
    if(!GetParameters(argc,argv))
        return -1;
    
    // ==================================================================================
    //2. Variable initializations and instance reading
    
    if (VERBOSE)
        cout<<"2. Reading instance "<<INSTANCE_FILENAME<<" and initializing variables..."<<endl;
    
    PROBLEM = new GPP();
    PROBLEM_SIZE= PROBLEM -> Read(INSTANCE_FILENAME);
    
    POP_SIZE=10*PROBLEM_SIZE;
    
    MAX_EVALUATIONS=100*PROBLEM_SIZE*PROBLEM_SIZE;

    SEL_SIZE=POP_SIZE/2;
    OFF_SIZE=POP_SIZE;
   
    BEST= new CIndividual(PROBLEM_SIZE);
    
    // ==================================================================================
    //3. Initializing Constrained EDA.

    if (VERBOSE)
        cout<<"3. Initializing Constrained EDA..."<<endl;

    //3.1. Initialize order
    Initialize_Order();
    
    //3.2. Initialize lattice uniformly at random.
    Initialize_Lattice_Uniformly();

    //3.3. Sample the initial population of solutions from the uniform lattice.
    POP= new CPopulation(POP_SIZE, OFF_SIZE, PROBLEM_SIZE);
    Sample_Initial(POP,POP_SIZE+OFF_SIZE);
   
    POP->SortPopulation(BEST);
   
    // ==================================================================================
    //4. Constrained EDA execution
    if (VERBOSE)
        cout<<"4. Running Constrained EDA..."<<endl;
    int iteration=0;
    int non_improvement=0;
    
    while (EVALUATIONS<MAX_EVALUATIONS){
        
        // 4.1. Learning
       // cout<<"Learning..."<<ORDER_TYPE<<" iteration:  "<<iteration<<endl;
        
        if ((ORDER_TYPE==2 && iteration!=0) || (ORDER_TYPE==3 && non_improvement==NON_IMPROVEMENT_ITERATIONS)){
            non_improvement=0;
            #ifdef PRINT_LOG
            cout<<"restart order"<<endl;
            #endif
            
            GreedyGraphGrowingPartitioning(ORDER, PROBLEM_SIZE, 1);
        }
        
        Learn(POP,SEL_SIZE);
        

        // 4.2. Sampling
        //cout<<"Sampling..."<<endl;
        if ((EVALUATIONS+OFF_SIZE)<MAX_EVALUATIONS){
            EVALUATIONS+= Sample(POP, OFF_SIZE);
        }
        else{
            EVALUATIONS+= Sample(POP, (int)(MAX_EVALUATIONS-EVALUATIONS));
        }
        non_improvement++;
               // 4.3. Update indicators and print logs.
        if (POP->SortPopulation(BEST)==true)
        {
            CONVERGENCE_EVALUATIONS=EVALUATIONS;
            #ifdef PRINT_LOG
            double average=POP->AverageFitness();
            cout<<"ITER: "<<iteration<<" , BS: "<<BEST->m_value<<" , AV: "<<average<<" , EV: "<<EVALUATIONS<<" , REM: "<<MAX_EVALUATIONS-EVALUATIONS<<endl;
            #endif
            non_improvement=0;
       
        }
        
        iteration++;
    }
    
    //5. Calculate consumed time and write results in file.
    gettimeofday(&tim, NULL);
    double t2=tim.tv_sec+(tim.tv_usec/1000000.0);
    cout<<"Final score: "<<BEST->m_value<<endl;
    cout<<"Time spent: "<<t2-t1<<endl;
    
   // exit(1);
#ifndef KALIMERO
    //Local executions
    FILE * test= fopen("/Users/Josu/Dropbox/EHU/Research/Ongoing activities/Lattice/newera_results.csv","r");
    FILE * result_file= fopen("/Users/Josu/Dropbox/EHU/Research/Ongoing activities/Lattice/newera_results.csv","a+");
    if (test==NULL){
        fprintf(result_file,"\"Instance\";\"Repetition\";\"Algorithm\";\"Fitness\";\"Time\"\n");
    }
    if (ORDER_TYPE==0) //identity
        fprintf(result_file,"\"%s\";%d;\"%s\";%ld;%.3f\n",INSTANCE_FILENAME,SEED,"ORDER_0",BEST->m_value,t2-t1);
    else if (ORDER_TYPE==1) //constructive only at the begining
        fprintf(result_file,"\"%s\";%d;\"%s\";%ld;%.3f\n",INSTANCE_FILENAME,SEED,"ORDER_1",BEST->m_value,t2-t1);
    else if (ORDER_TYPE==2) //random every iteration
        fprintf(result_file,"\"%s\";%d;\"%s\";%ld;%.3f\n",INSTANCE_FILENAME,SEED,"ORDER_2",BEST->m_value,t2-t1);
    else if (ORDER_TYPE==3) //constructive at non_improvement
        fprintf(result_file,"\"%s\";%d;\"%s\";%ld;%.3f\n",INSTANCE_FILENAME,SEED,"ORDER_3",BEST->m_value,t2-t1);

    fclose(result_file);
    fclose(test);
#endif
    
#ifdef KALIMERO
    //In Kalimero
    FILE * result_file= fopen("./scratch_results.csv","w");
    //fprintf(result_file,"\"Instance\";\"Repetition\";\"Algorithm\";\"Fitness\";\"Time\"\n");
    fprintf(result_file,"\"%s\";%d;\"%s\";%ld;%.3f\n",INSTANCE_FILENAME,SEED,"LATTICE_new",BEST->m_value,t2-t1);
    fclose(result_file);
#endif
    
    //6. Delete structures
    for (int i=0;i<PROBABILITY_MATRIX_LENGTH;i++){
        delete [] PROBABILITY_MATRIX[i];
        delete [] UNIFORM_PROBABILITY_MATRIX[i];
    }
    delete [] PROBABILITY_MATRIX;
    delete [] UNIFORM_PROBABILITY_MATRIX;
    delete [] ORDER;
    delete [] SOLUTION;
    delete [] RANDOM_VALUES;
    delete POP;
    delete BEST;
    return 0;
}

long double nchoosek(long n, long k){
    
    if (k > n) return 0;
    if (k * 2 > n) k = n-k;
    if (k == 0) return 1;
    
    long double result = n;
    for( int i = 2; i <= k; ++i ) {
        result *= (n-i+1);
        result /= i;
    }
    return result;
    
}

/*
 * Initializes the lattices uniformly at random.
 */
void Initialize_Lattice_Uniformly(){
    //PROBLEM_SIZE=6;
    PROBABILITY_MATRIX_LENGTH=pow(PROBLEM_SIZE/2+1,2); //the last state (n/2,n/2) is the final state, and therefore, we remove that position.
    UNIFORM_PROBABILITY_MATRIX= new long double*[PROBABILITY_MATRIX_LENGTH];
    PROBABILITY_MATRIX= new double*[PROBABILITY_MATRIX_LENGTH];
    for (int i=0;i<PROBABILITY_MATRIX_LENGTH;i++){
        UNIFORM_PROBABILITY_MATRIX[i]= new long double[2];
        PROBABILITY_MATRIX[i]= new double[2];
    }
    long x, y;
    long factor=(PROBLEM_SIZE/2)+1;
    long double val;
    //1. revisar que este for está bien con un ejemplo hecho a mano!!!!
    for (x=0;x<factor;x++){
        for (y=0;y<factor;y++){
            val=nchoosek((factor-1-x)+(factor-1-y), (factor-1-x));
            UNIFORM_PROBABILITY_MATRIX[x*factor+y][0]=val;
            UNIFORM_PROBABILITY_MATRIX[x*factor+y][1]=val;
        }
    }
    //PrintMatrix(UNIFORM_PROBABILITY_MATRIX, PROBABILITY_MATRIX_LENGTH, 2);
    
    long double suma;
    for (x=0;x<factor-1;x++){
        for (y=0;y<factor-1;y++){
            suma=(UNIFORM_PROBABILITY_MATRIX[(x+1)*factor+y][0]+UNIFORM_PROBABILITY_MATRIX[x*factor+(y+1)][0]);
            UNIFORM_PROBABILITY_MATRIX[x*factor+y][0]=UNIFORM_PROBABILITY_MATRIX[x*factor+(y+1)][0]/suma;
            UNIFORM_PROBABILITY_MATRIX[x*factor+y][1]=UNIFORM_PROBABILITY_MATRIX[(x+1)*factor+y][1]/suma;
        }
    }
    
    //first node.
    UNIFORM_PROBABILITY_MATRIX[0][0]=1;
    UNIFORM_PROBABILITY_MATRIX[0][1]=0;
    
    y=factor-1;
    for (x=0;x<factor;x++){
        UNIFORM_PROBABILITY_MATRIX[x*factor+y][0]=0;
        UNIFORM_PROBABILITY_MATRIX[x*factor+y][1]=1;
     }
    x=factor-1;
     for (y=0;y<factor;y++){
         UNIFORM_PROBABILITY_MATRIX[x*factor+y][0]=1;
         UNIFORM_PROBABILITY_MATRIX[x*factor+y][1]=0;
     }
    
    UNIFORM_PROBABILITY_MATRIX[PROBABILITY_MATRIX_LENGTH-1][0]=0;
    UNIFORM_PROBABILITY_MATRIX[PROBABILITY_MATRIX_LENGTH-1][1]=0;
}

/*
 * Generates a random binary solution of size 'n' in the given array with equal number of 0s and 1s.
 */
void GenerateRandomBinaryBalanced(int * solution, long n)
{
    std::fill_n(solution,n,0);
    int i=0; // In order to avoid symmetry in the problem, we fix in the first position always 0.
    int pos;
    while (i<(n/2)){
        pos=1+(rand()%(n-1));// In order to avoid symmetry in the problem, we fix in the first position always 0.
        if (solution[pos]==0){
            solution[pos]=1;
            i++;
        }
    }
}

/*
 * Generates a random permutation of size 'n' in the given array.
 */
void GenerateRandomPermutation(int * permutation, int n)
{
    int j,i;
    for (i = 0; i < n; ++i)
    {
        j = rand() % (i + 1);
        permutation[i] = permutation[j];
        permutation[j] = i;
    }
}

/*
 * Given a population of solutions, it calculates the parameters of the probabilistic model.
 */
void Learn(CPopulation * pop, int num_solutions_to_learn){
    
    //auxiliary variables
    long i,j;
    int * solution;
    
    //start from uniform probability matrix.
    for (i=0;i<PROBABILITY_MATRIX_LENGTH;i++){
        //memcpy(PROBABILITY_MATRIX,UNIFORM_PROBABILITY_MATRIX,sizeof(float)*2);
        std::fill_n(PROBABILITY_MATRIX[i],2,0);
    }
    

    long zeros, ones;
    long factor=(PROBLEM_SIZE/2)+1;
    long row;
    int col;
    //estimate parameters of probability matrix.
    for (i=0;i<num_solutions_to_learn;i++){
        solution=pop->m_individuals[i]->m_solution;
       // PrintArray(solution, PROBLEM_SIZE);
        zeros=0; ones=0;
       // printf("i: %ld",i);
        for (j=0;j<PROBLEM_SIZE;j++){
            row=(ones*factor)+(zeros);
            col=(solution[ORDER[j]]==1);
            
            PROBABILITY_MATRIX[row][col]++;
            zeros=zeros+(!col);
            ones=ones+(col);
        }
      //  exit(1);
    }
    //PrintMatrix(PROBABILITY_MATRIX, PROBABILITY_MATRIX_LENGTH, 2);
    //first node
    PROBABILITY_MATRIX[0][0]=1;
    PROBABILITY_MATRIX[0][1]=0;
    
    double sum=0;
    for (i=1;i<PROBABILITY_MATRIX_LENGTH;i++){
        sum=PROBABILITY_MATRIX[i][0]+PROBABILITY_MATRIX[i][1];
        if (sum==0){
            PROBABILITY_MATRIX[i][0]=UNIFORM_PROBABILITY_MATRIX[i][0]; //esto es lo correcto.
            PROBABILITY_MATRIX[i][1]=UNIFORM_PROBABILITY_MATRIX[i][1]; //esto es lo correcto
        }
        else{
            PROBABILITY_MATRIX[i][0]=(PROBABILITY_MATRIX[i][0]+1)/(sum+2); // with laplace correction
            PROBABILITY_MATRIX[i][1]=(PROBABILITY_MATRIX[i][1]+1)/(sum+2); // with laplace correction
        }
    }

    
    long y=factor-1;
    long x;
    for (x=0;x<factor;x++){
        PROBABILITY_MATRIX[x*factor+y][0]=0;
        PROBABILITY_MATRIX[x*factor+y][1]=1;
    }
    x=factor-1;
    for (y=0;y<factor;y++){
        PROBABILITY_MATRIX[x*factor+y][0]=1;
        PROBABILITY_MATRIX[x*factor+y][1]=0;
    }
    
    //last node
    PROBABILITY_MATRIX[PROBABILITY_MATRIX_LENGTH-1][0]=0;
    PROBABILITY_MATRIX[PROBABILITY_MATRIX_LENGTH-1][1]=0;
   //PrintMatrix(PROBABILITY_MATRIX, PROBABILITY_MATRIX_LENGTH, 3);
    //exit(1);
}


/*
 * Samples new solutions from the probabilistic model.
 */
int Sample_Initial(CPopulation * pop, int num_samples){
    
    SOLUTION= new int[PROBLEM_SIZE];
    RANDOM_VALUES=new double[PROBLEM_SIZE];
    //cout<< "num samples: "<<num_samples<<endl;
    int i;
    long j;
    long zeros, ones;
    long factor=(PROBLEM_SIZE/2)+1;
    double val,sum;
    for (i=0;i<num_samples;i++){
        std::fill_n(SOLUTION,PROBLEM_SIZE,0);
        //SOLUTION[ORDER[0]]=0;//in the first position always 0.
        zeros=1; //in the first position always 0.
        ones=0;

        //cout<<i<<endl;
        for (j=1;j<PROBLEM_SIZE;j++){
            sum=UNIFORM_PROBABILITY_MATRIX[(ones*factor)+zeros][0]+UNIFORM_PROBABILITY_MATRIX[(ones*factor)+zeros][1];
            val = ((double)rand() / ((double)RAND_MAX ) ) * sum;
            //cout<<"val: "<<val<<endl;
            //cout<<"zeros: "<<zeros<<"  ones: "<<ones<<" probabilityzeros: "<<PROBABILITY_MATRIX[(zeros*factor)+ones][0]<<endl;
            if (val>=UNIFORM_PROBABILITY_MATRIX[(ones*factor)+zeros][0]){
            
                SOLUTION[ORDER[j]]=1;
                //cout<<"one"<<endl;
                ones++;
            }
            else{
                //  cout<<"zero"<<endl;
               // SOLUTION[ORDER[j]]=0;
                zeros++;
            }
        }
        //save new solution in the population
        pop->SetToPopulation(SOLUTION, i, PROBLEM->Evaluate(SOLUTION));
        EVALUATIONS++;
    }
    return num_samples;
}

/*
 * Samples new solutions from the probabilistic model.
 */
int Sample(CPopulation * pop, int num_samples){
   //  cout<<"num samples: "<<num_samples<<endl;
   // pop->Print(num_samples);
    int i;
    long j;
    long zeros, ones;
    long factor=(PROBLEM_SIZE/2)+1;
    
    for (i=0;i<num_samples;i++){
std::fill_n(SOLUTION,PROBLEM_SIZE,0);        
        for (j=1;j<PROBLEM_SIZE;j++)
            RANDOM_VALUES[j]=((double)rand() / ((double)RAND_MAX) );
        //SOLUTION[ORDER[0]]=0;//in the first position always 0.
        zeros=1; //in the first position always 0.
        ones=0;
       //  VISIT_MATRIX[(PROBLEM_SIZE/2)-(ones)][zeros]++;
        //cout<<"i: "<<i<<endl;
        for (j=1;j<PROBLEM_SIZE;j++){
            //cout<<"val: "<<val<<" prob: "<<PROBABILITY_MATRIX[(ones*factor)+zeros][0]<<endl;
            //cout<<"zeros: "<<zeros<<"  ones: "<<ones<<endl;
            if (RANDOM_VALUES[j]>=PROBABILITY_MATRIX[(ones*factor)+zeros][0]){
              //  cout<<"zero"<<endl;
                SOLUTION[ORDER[j]]=1;
                //cout<<"one"<<endl;
                ones++;
            }
            else{
                //SOLUTION[ORDER[j]]=0;
                zeros++;
            }
        }
        
        if (pop->Exists(SOLUTION, PROBLEM_SIZE, POP_SIZE+i)==false){
            //save new solution in the population
           // PrintArray(SOLUTION, PROBLEM_SIZE);
            pop->SetToPopulation(SOLUTION, pop->m_pop_size+i, PROBLEM->Evaluate(SOLUTION));
        }
        else{
            i--; //this has been commented recently.
        }
        
    }
    return num_samples;
}

/*
 * Prints in the standard output the 'size' elements of the given array..
 */
void PrintArray(int * array, long size)
{
    for (long i=0;i<size;i++){
        cout<<array[i]<<" ";
    }
    cout<<" "<<endl;
}

/*
 * Prints in the standard output the 'size' elements of the given array..
 */
void PrintArray(float * array, long size)
{
    for (long i=0;i<size;i++){
        cout<<array[i]<<" ";
    }
    cout<<" "<<endl;
}

/*
 * Prints in the standard output the 'size' elements of the given array..
 */
void PrintArray(long double * array, long size)
{
    for (long i=0;i<size;i++){
        cout<<array[i]<<" ";
    }
    cout<<" "<<endl;
}

/*
 * Prints in the standard output given matrix.
 */
void PrintMatrix(long** matrix, long length, int length2)
{
    int i,j;
    for (i=0;i<length;i++)
    {
        for (j=0;j<length2-1;j++)
        {
            printf("%ld;",matrix[i][j]);
        }
        printf("%ld",matrix[i][j]);
        printf("\n");
    }
    printf("\n");
}

/*
 * Prints in the standard output given matrix.
 */
void PrintMatrix(float** matrix, long length, int length2)
{
    int i,j;
    for (i=0;i<length;i++)
    {
        for (j=0;j<length2;j++)
        {
            printf("%.2f\t",matrix[i][j]);
        }
        printf("\n");
    }
    printf("\n");
}
/*
 * Prints in the standard output given matrix.
 */
void PrintMatrix(double** matrix, long length, int length2)
{
    int i,j;
    for (i=0;i<length;i++)
    {
        for (j=0;j<length2;j++)
        {
            printf("%.2g\t",matrix[i][j]);
        }
        printf("\n");
    }
    printf("\n");
}

/*
 * Prints in the standard output given matrix.
 */
void PrintMatrix(long double** matrix, long length, int length2)
{
    int i,j;
    for (i=0;i<length;i++)
    {
        for (j=0;j<length2;j++)
        {
            printf("%.2Lg\t",matrix[i][j]);
        }
        printf("\n");
    }
    printf("\n");
}
/*
 * It determines if the given int sequecen if it is indeed a permutation or not.
 */
bool isPermutation(int * permutation, long size)
{
    int flags[size];
    //int * flags=new int[size];
    for (int i=0;i<size;i++) flags[i]=1;
    
    for (int i=0;i<size;i++)
    {
        int value=permutation[i];
        flags[value]=0;
    }
    
    int result,sum=0;
    for(int i=0;i<size;i++)
        sum+=flags[i];
    if (sum==0) result=true;
    else result=false;
    //delete [] flags;
    return result;
}


/*
 * Initializes the order of variables in the model
 */
void Initialize_Order(){
    ORDER= new int[PROBLEM_SIZE];
    if (ORDER_TYPE==0){
        for (int i=0;i<PROBLEM_SIZE;i++)
            ORDER[i]=i;
    }
    
    else{
        GreedyGraphGrowingPartitioning(ORDER,(int)PROBLEM_SIZE, 1);
#ifdef PRINT_LOG
        PrintArray(ORDER,PROBLEM_SIZE);
#endif
        if (isPermutation(ORDER, PROBLEM_SIZE)==false){
            cout<<"Horror!! is not a permutation"<<endl;
        }
    }
}

/*
 * Calculates the entry value of the variables based on the solutions in the population.
 */
void CalculateEntropyVectorOfPopulationVariables(long double * entropy){

    int pos,index_pop;
    for (pos=0;pos<PROBLEM_SIZE;pos++)
        entropy[pos]=0;
    
    for (index_pop=0;index_pop<POP_SIZE;index_pop++){
        for (pos=0;pos<PROBLEM_SIZE;pos++){
            entropy[pos]+=(POP->m_individuals[index_pop]->m_solution[pos]==1);
        }
    }
    long double value;
    long double p,q;
    for (pos=0;pos<PROBLEM_SIZE;pos++){
        entropy[pos]=(entropy[pos])/(POP_SIZE+1);
        p=(entropy[pos]+1)/(POP_SIZE+1);
        q=1-p;
        //cout<<"pos: "<<pos<<" p: "<<p<<"  q: "<<q<<endl;
        value=-1*( p*log2(p) + q*log2(q) );
        entropy[pos]=value;
    }
    
}

/*
 * Stores the order of the items that have been considered in the Constructive algorithm called Greedy GGP.
 */
void GreedyGraphGrowingPartitioning(int * order, long size, int iterations){
  
    //COUNT_TIES=0;
    //declare partitions. Partition 1 is coded as 0 and partition 2 is coded as 1.
    list<int> partition1;
    list<int> partition2;
    list<int> non_assigned;

    //Add item 0 at partition 1 as default.
    int vertex_for_p1=0;
    partition1.push_back(vertex_for_p1);
    order[0]=vertex_for_p1;
    
    //Generate randomly another seed for partition 2.
    int vertex_for_p2=1+(rand()%(size-1));
    partition2.push_back(vertex_for_p2);
    //order[1]=vertex_for_p2;
    //order[PROBLEM_SIZE-1]=vertex_for_p2;
    order[size/2]=vertex_for_p2;
    
    
    //Generate the list of non-asigned solutions.
    int i;
    for(i=1;i<vertex_for_p2;i++)
        non_assigned.push_back(i);
    for(i=vertex_for_p2+1;i<size;i++)
        non_assigned.push_back(i);
    
    //start iterating and adding solutions to the different partitions.
    int index=1;
    
   // cout<<"part 1: "<<vertex_for_p1<<endl;
    //cout<<"part 2: "<<vertex_for_p2<<endl;
    
    while(non_assigned.empty()==false){
        //next vertex for partition one.
        vertex_for_p1=MinimumTotalGain_Vertex(partition1,partition2,non_assigned);
        partition1.push_back(vertex_for_p1);
        non_assigned.remove(vertex_for_p1);
        order[index]=vertex_for_p1;
        
        //next vertex for partition one.
        vertex_for_p2=MinimumTotalGain_Vertex(partition2,partition1,non_assigned);
        partition2.push_back(vertex_for_p2);
        non_assigned.remove(vertex_for_p2);
        //order[index+1]=vertex_for_p2;
        order[(size/2)+index]=vertex_for_p2;
        //order[PROBLEM_SIZE-index-1]=vertex_for_p2;
     //   cout<<vertex_for_p1<<"    -    "<<vertex_for_p2<<endl;
        //update index
        index=index+1;
        
     //   exit(1);
    }
    partition1.clear();
    partition2.clear();
    non_assigned.clear();
    
 //   cout<<"TIES: "<<COUNT_TIES<<endl; exit(1);
   // exit(1);
}

/*
 * Returns the vertex with the minimum total gain from the non_assigned_vertices.
 */
int MinimumTotalGain_Vertex(list<int> partition_of_interest,list<int> other_partition, list<int> non_assigned_vertices){
    //declare variables.
  //  cout<<"------------------------------------"<<endl;
    int best_item=-1;
    double min_total_gain= 100000000;
    double total_gain,dividendo,divisor;

    //search.
    std::list<int>::iterator it,it2;
    for (it=non_assigned_vertices.begin(); it!=non_assigned_vertices.end();it++){
       
        divisor=0;
        for (it2=partition_of_interest.begin();it2!=partition_of_interest.end();it2++){
            divisor+=PROBLEM->m_edge_weights[*it][*it2];
        }
        dividendo=0;
        for (it2=other_partition.begin();it2!=other_partition.end();it2++){
            dividendo+=PROBLEM->m_edge_weights[*it][*it2];
        }
        if (divisor!=0){
            total_gain=dividendo/divisor;
        }
        else{
            total_gain=dividendo;
        }
       // cout<<"iterator: "<<*it<<" total gain: "<<total_gain<<" dividendo: "<<dividendo<<endl;
        //update best item with minimum total gain found so far.
        if (min_total_gain>total_gain){
            min_total_gain=total_gain;
            best_item=*it;
        }
        else if (min_total_gain==total_gain && (((float)rand()/(float)RAND_MAX)<0.5) ){
            best_item=*it;
        }
    }
    
    return best_item;
    
    
}

/*
 * Calculates the pyramidal order of the values according to the vector of doubles.
 */
void GetPyramidalOrder( int * a, long double * criteriaValues, int size)
{
    
    float criteria, mint;
    int i, j;
    std::fill_n(a,size,0);
    std::fill_n(FIXED_VALUES,size,0);
    
    int minPos=0;
    for (i=0;i<(size/2);i++)
    {
        mint=INT_MIN;
        for (j=0;j<size;j++)
        {
            criteria=criteriaValues[j];
            if (!FIXED_VALUES[j] && mint<criteria )
            {
                mint=criteria;
                minPos=j;
            }
        }
        
        FIXED_VALUES[minPos]=true;
        a[i]=minPos;
        
        mint=INT_MIN;
        for (j=0;j<size;j++)
        {
            criteria=criteriaValues[j];
            if (!FIXED_VALUES[j] && mint<criteria )
            {
                mint=criteria;
                minPos=j;
            }
        }
        
        FIXED_VALUES[minPos]=true;
        a[PROBLEM_SIZE-1-i]=minPos;
    }
}

/*
 * Calculates the pyramidal order of the values according to the vector of doubles. Ties are broken randomly.
 */
void GetPyramidalOrder_Randomness( int * a, long double * criteriaValues, int size)
{
    
    float criteria, mint;
    int i, j;
    std::fill_n(a,size,0);
    std::fill_n(FIXED_VALUES,size,0);
    
    int minPos=0;
    for (i=0;i<(size/2);i++)
    {
        mint=INT_MIN;
        for (j=0;j<size;j++)
        {
            criteria=criteriaValues[j];
            if (!FIXED_VALUES[j] && mint<criteria )
            {
                mint=criteria;
                minPos=j;
            }
            else if (!FIXED_VALUES[j] && mint==criteria && ((float)rand()/(float)RAND_MAX)<0.5 ){
                mint=criteria;
                minPos=j;
            }
        }
        
        FIXED_VALUES[minPos]=true;
        a[i]=minPos;
        
        mint=INT_MIN;
        for (j=0;j<size;j++)
        {
            criteria=criteriaValues[j];
            if (!FIXED_VALUES[j] && mint<criteria )
            {
                mint=criteria;
                minPos=j;
            }
            else if (!FIXED_VALUES[j] && mint==criteria && ((double)rand()/RAND_MAX)<0.5 ){
                mint=criteria;
                minPos=j;
            }
        }
        
        FIXED_VALUES[minPos]=true;
        a[PROBLEM_SIZE-1-i]=minPos;
    }
}

/*
 * Calculate the Hamming distance between two solutions A and B.
 */
int Distance(int * solutionA,int * solutionB){
    int sum=0;
    for (int i=0;i<PROBLEM_SIZE;i++){
        sum+=(solutionA[i]!=solutionB[i]);
    }
    return sum;
}



