// BayesianNetwork.cpp: implementation of the CBayesianNetwork class.
//

#include "BayesianNetwork.h"
#include <errno.h>
#include <fcntl.h>
#include <string.h>
#include <math.h>
#include <limits.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
//#include <mach/mach_time.h>
using std::cerr;
using std::cout;
using std::endl;
#define itoa(a,b,c) sprintf(b, "%d",a)

extern int generaciones; 
timeval CANin,CANout,nin,nout,blearnin,blearnout,lorientin,lorientout;
long double torient=0.0;
long double tlearnpc=0.0;


CBayesianNetwork::CBayesianNetwork(int problem_size, int sel_size, int learning, int sampling)
{
    int i,j;
    
    m_learning=learning;
    m_sampling=sampling;
    
    m_problem_size=problem_size;
    m_sel_size=sel_size;
    // An arcless Bayesian network is created. All nodes have
    // no parents.
    m_parents = new bool*[m_problem_size];
    for(i=0;i<m_problem_size;i++)
    {
        m_parents[i] = new bool[m_problem_size];
        for(j=0;j<m_problem_size;j++) m_parents[i][j] = false;
    }
	
	// Thus, there are no paths among nodes.
    m_paths = new int*[m_problem_size];
    for(i=0;i<m_problem_size;i++)
    {
        m_paths[i] = new int[m_problem_size];

        for(j=0;j<m_problem_size;j++)
            if(i==j) m_paths[i][j] = 1;
            else m_paths[i][j] = 0;
    }

    // The probability distribution will be uniform.
    m_probs = new double*[m_problem_size];
    for(i=0;i<m_problem_size;i++)
    {
        m_probs[i] = new double[2-1];
        // The final probability is found subtracting
        // all the others to 1.

        for(j=0;j<2-1;j++) 
            m_probs[i][j] = 1/(double)2; //0.964
    }

    // The order is trivial.
    m_order = new int[m_problem_size];
    for(i=0;i<m_problem_size;i++) m_order[i] = i;

    // The ordered nodes can be found from m_order.
    m_ordered = new int[m_problem_size];
    for(i=0;i<m_problem_size;i++) m_ordered[m_order[i]] = i;

    // memory for m_A is allocated.
    m_A = new long double*[m_problem_size];
    for(i=0;i<m_problem_size;i++)
    {
        m_A[i] = new long double[m_problem_size];
        for(j=0;j<m_problem_size;j++) m_A[i][j] = INT_MIN;
    }

    // Matrix to record the actual state of the Bayesian network.
    m_ActualMetric = new double[m_problem_size];
    
    //data structures for tree
    m_mi = new double*[m_problem_size];
    m_upaths = new bool*[m_problem_size];
    m_edges = new bool*[m_problem_size];
    m_pbat= new double[m_problem_size];
    m_pbi= new double[m_problem_size];
    m_pbatbi= new double*[m_problem_size];
    for (j=0;j<m_problem_size;j++)
    {
        m_mi[j] = new double[m_problem_size];
        m_upaths[j] = new bool[m_problem_size];
        m_edges[j] = new bool[m_problem_size];
        m_pbatbi[j]= new double[m_problem_size];
    }
}

CBayesianNetwork::~CBayesianNetwork()
{
    int i;

    for(i=0;i<m_problem_size;i++) delete [] m_probs[i];
    delete [] m_probs;

    delete [] m_order;
    delete [] m_ordered;

    for(i=0;i<m_problem_size;i++) delete [] m_parents[i];
    delete [] m_parents;

    for(i=0;i<m_problem_size;i++) delete [] m_A[i];
    delete [] m_A;

    for(i=0;i<m_problem_size;i++) delete [] m_paths[i];
    delete [] m_paths;

    delete [] m_ActualMetric;

    for(i=0;i<m_problem_size;i++)
    {
        delete [] m_mi[i];
        delete [] m_upaths[i];
        delete [] m_edges[i];
        delete [] m_pbatbi[i];
    }
    delete [] m_mi;
    delete [] m_upaths;
    delete [] m_edges;
    delete [] m_pbat;
    delete [] m_pbi;
    delete [] m_pbatbi;
}

void CBayesianNetwork::Simulate(int * solution)
{
    int i, j, v, variable;

    //Variables to modify the simulation step
    int *Indiv = new int[2]; //we assume that, when using PLS_ALL_VALUES_x,
                     //the number of states of all 
                     //variables is always the same
    for (i=0; i<2; i++)
        Indiv[i]=0;
    int variables_left = m_problem_size;
    int values_left = 2;
    double P_indiv, K;
    double sum;

    //table to store all the probabilities and access them more easily
    int max_states=0; //variable to compute which is the maximum number of states of any of the variables
    for(i=0; i<m_problem_size; i++)
    {
    	if(max_states<2)
     	{
		    max_states=2;
     	}
    }
    double *Prob_table = new double [max_states];

    bool stop=false; int zeros=0, ones=0;
    // The individual will be generated simulating its
    // genes according to the order they have in the
    // Bayesian network.
    for(variable=0;variable<m_problem_size && (stop==false);variable++)
    {
        double which = double(double(rand())/RAND_MAX);

        //calculate the probabilities and store them in the probability table
        double * probs = Probabilities(m_ordered[variable],solution);

        sum=0.0;
        for (i=0; i<2-1; i++) {
            Prob_table[i] = probs[i];
            sum += probs[i];
        }
        Prob_table[2-1]=1-sum; //prob. of last variable = 1 - sum of the rest

        //Modify the probabilities to get correct individuals
        switch (m_sampling)
        {
        case PLS:               
            break; //PLS simple, no modifications

        case PLS_CORRECT:               
            break; //PLS simple, modifications later

        case PLS_ALL_VALUES_1:
        	//LTM
            if (variables_left==values_left) {
                P_indiv=0.0;
                for (i=0; i<2; i++)
                    if (Indiv[i]>0) 
                        P_indiv += Prob_table[i];
                for (i=0; i<2; i++) {
                    if (Indiv[i]>0) 
                        Prob_table[i] = 0.0;
                    else 
                        Prob_table[i] *= 1/(1-P_indiv);
                }
            }
            break;
        
        case PLS_ALL_VALUES_2:  
        	//ATM
            if (values_left>0)
            {

                //calculate P_indiv
                P_indiv=0.0;
                for (i=0; i<2; i++) 
                    if (Indiv[i]>0) 
                        P_indiv += Prob_table[i];

                //Change the probabilities of all values
                if (variables_left==values_left) {
                    for (i=0; i<2; i++) {
                        if (Indiv[i]>0) 
                            Prob_table[i]=0.0;
                        else 
                            Prob_table[i] *= 1/(1-P_indiv);
                    }
                } else {
                    //calculate K, the constant to divide the probabilities
                    K=int((m_problem_size - variables_left)/(variables_left - values_left))+1;
                    //K = round(K);

                    for (i=0; i<2; i++) {
                        if (Indiv[i]>0) 
                            Prob_table[i] /= K;
                        else 
                            Prob_table[i] *= (K - P_indiv)/(K*(1-P_indiv));
                    }
                }
            }
            break;
        }
        
        int j;
        for(j=0;j<(2-1) && which>Prob_table[j];j++)
            which -= Prob_table[j];

        //Correct the problem of the rounding in the computer
        if (Prob_table[j]==0.0) {
            if (j==0) //we will select the next variable that has a prob!=0
                do {j++;} while (Prob_table[j]==0.0);
            else //we will select the previous variable that has a prob!=0
                do {j--;} while (Prob_table[j]==0.0);
        }

        solution[m_ordered[variable]] = j;
        
        //for the graph partitioning problem
        zeros+=(j==0);
        ones+=(j==1);
        if (zeros==(m_problem_size/2) || ones==(m_problem_size/2)){
            stop=true;
        }
        
        variables_left--;
        if (Indiv[j]==0) values_left--;
        Indiv[j]++;
    }

    //Correct the individual if necessary and requested
    if ((m_sampling==PLS_CORRECT)&&(values_left>0) && stop==false)
    {
        while (values_left>0)
        {
            //select a random position that contains a variable already appeared at least twice
            do
            {
            	j=rand()%m_problem_size;
            }
            while (Indiv[solution[j]]<2);
            //cout <<variable<<endl;
            //substitute this variable by next the missing value.
            for (v=0; v<2; v++)
            {
        		//cout << "states repetition: "<<Indiv[0]<<" "<<Indiv[1]<<" "<<Indiv[2]<<" "<<Indiv[3]<<endl;
        		//cout<< "checked variable that equals 0 is: "<<v<<endl;
            	if (Indiv[v]==0)
            	{
            		//cout<<"entra"<<endl;
            		break;
            	}
            }
            //cout << "individual before: "<<genes[0]<<" "<<genes[1]<<" "<<genes[2]<<" "<<genes[3]<<endl;
            //cout<< "replaced gene position:"<<j<<endl;
            //cout<< "old gene value:"<<genes[j]<<endl;
            Indiv[solution[j]]--;
            solution[j]=v;
            Indiv[v]++;
            values_left--;
            //cout<< "new gene value:"<<genes[j]<<endl;
            //cout << "individual after: "<<genes[0]<<" "<<genes[1]<<" "<<genes[2]<<" "<<genes[3]<<endl;
        }

    }
    if ((m_sampling==PLS_CORRECT && stop==true)){
        //cout<<"here2"<<endl;
        if (zeros==(m_problem_size/2)){
            for (i=(zeros+ones);i<m_problem_size;i++){
                solution[m_ordered[i]]=1;
            }
        }
        else{
            for (i=(zeros+ones);i<m_problem_size;i++){
                solution[m_ordered[i]]=0;
            }
        }
    }
    
    //Code neccessary only for Endika's program. Please, keep it commented otherwise
    //it keeps record of the correctness of the individual generated.
    /*switch(values_left) {
    case 0: POPCORRECT++; break;
    case 1: POPMISS1++; break;
    case 2: POPMISS2++; break;
    case 3: POPMISS3++; break;
    default: POPMISSMORE++;
    }*/

    delete [] Indiv;
    delete [] Prob_table;

  /*  int suma=0;
    for (long i=0;i<m_problem_size;i++){
        suma+=(solution[i]);
    }
    if (suma!=(m_problem_size/2)){
        cout<<"incorrent individual sampled"<<endl;
        exit(1);
        
    }*/
    
      //  for (long i=0;i<m_problem_size;i++){
      //      cout<<solution[i]<<" ";
      //  }
      //  cout<<" "<<endl;
    
    //individual->m_values_left = values_left;
    //cout<<"values left in individual "<<values_left<<endl;
    //return individual;
    //exit(1);
}

void CBayesianNetwork::Learn(CPopulation* population)
{
    
    // Learn the structure
    switch(m_learning)
    {
        case EBNA_B:
            LearnEBNAB(population);
            break;
            
        case TREE:
            LearnTree(population);
            break;
    }
    
	// Learn the probabilities
    LearnProbabilities(population);
}

double * CBayesianNetwork::Probabilities(int ordered_node, 
                                         int * instance)
{
    // First the configuration of the parent nodes is
    // found.
    int parent_configuration = 0;
    int i;
    for(i=0;i<m_problem_size;i++)
    {
        if(m_parents[ordered_node][i]) 
        {
            parent_configuration *= 2;
            parent_configuration += instance[i];
        }
    }

    // Then the conditional probability corresponding to that
    // parent configuration is returned.
    return &(m_probs[ordered_node]
	     [parent_configuration*(2-1)]);
}
 
void CBayesianNetwork::LearnProbabilities(CPopulation * population)
{
    long i,j,k;
    int ** nijk=NULL;

    ////////////// PROBABILIDADES EN FICHERO (CARLOS)/////////////////
    double ** probs_i = NULL; // Para guardar los parametros asociados a una variable
    double * probs_list = NULL; // vector que guarda las probabilidades de probs_i en el orden que estan
    int no_p; //Numero de padres/////
    
    for(i=0;i<m_problem_size;i++)
    {
	   // Calculate the number of parent configurations of i.
        long no_j = 1;
        for(j=0; j<m_problem_size; j++)
        {
            if (m_parents[i][j])
            {
            	//cout<<"Parent between i:"<<i<<" j: "<<j<<endl;
            	no_j *= 2;
            }
        }
        //cout<<"Allocating memory. Gene i: "<<i<<" Dimensiones: "<<no_j<<" "<<2<<endl;

        // Allocate memory for all nijk-s.
        nijk=NULL;
        nijk = new (int (* [no_j]));
		for(j=0;j<no_j;j++)
        {
            nijk[j] = new int[2];
            for(k=0;k<2;k++)
            	nijk[j][k] = 0;
        }

		//cout<<"Calculating nijk. Gene i: "<<i<<endl;

        // All nijk-s are calculated.
        for(j=0;j<m_sel_size;j++)
        {
            no_p = 0;
            int parent_configuration = 0;
            for(int parent=0;parent<m_problem_size;parent++)
            {
                if(m_parents[i][parent])
                {
                    // Calcula la configuraci�n a partir de los datos
                    // Calcula las potencias y pone la configuraci�n actual de los padres en base 10
                    // En cases est�n desordenadosp pero al colocarlos en nijk se ordenan
                    parent_configuration *= 2; //Multiplica por la potencia correspondiente
                    parent_configuration += population->m_individuals[j]->m_solution[parent]; //Suma el numero
                    no_p++;
                }
            }
            nijk[parent_configuration][population->m_individuals[j]->m_solution[i]]++;
        }

        // All probabilities are recalculated (as Buntine).
    
        if (m_learning != PBIL)
        { 
            delete [] m_probs[i];
            m_probs[i] = new double[no_j*(2-1)];
        }


        // PBIL needs the probabilities of the prior population.
        // Other learning algorithms do not need them.
        //////////////////// CARLOS //////////////
        probs_i = NULL;
        probs_i = new (double (* [no_j])); 
        ///////////////////////////////////////////
        for(j=0;j<no_j;j++)
        {
            ////////////////// CARLOS   //////////////////////////
            probs_i[j] = new double[2];
            double sum = 0.0; // Para el calculo del ultimo parametro
            ///////////////////////////////////////////////////
            int nij = 0;
            for(k=0;k<2;k++) nij += nijk[j][k];

            double BDeu = (double)1/2/no_j;

            // Also when the BN is induced by EDA, conditional
            // probabilities are calculated in univariated=UMDA form
            if ((m_learning != PBIL) && (m_learning != BSC))
            {
                int k;
                for(k=0;k<2-1;k++)
                {    m_probs[i][j*(2-1)+k] =
                        (double)(nijk[j][k]+BDeu)/
                        (double)(nij+2*BDeu);
                   
                    /////////// CARLOS /////////////////////////
                    sum += m_probs[i][j*(2-1)+k];
                    probs_i[j][k] =  m_probs[i][j*(2-1)+k]; //Mtriz con los par�metros de Xi
                    ///////////////////////////////////////
               
                }

                //////////////////////////
                probs_i[j][k] = 1 - sum;  // A�adir el �ltimo par�metro a la matriz
                ////////////////////////

            }
        }
         
        // Memory used for nijk-s is released.
        for(j=0;j<no_j;j++) 
        {
        	delete [] nijk[j];
        	delete [] probs_i[j];
        }
        delete [] probs_list;
        delete [] nijk;
        delete [] probs_i;

    
   } // fin Xi

}

/******************************************************
 ******************************************************
                         TREE
 ******************************************************
 ******************************************************/


void CBayesianNetwork::LearnTree(CPopulation * population)
{
	int i,j,k,l,r;

    int withnocycles = 0;
    int max_i = 0;
    int max_j = 0;
    double max_mi = 0.0;
    bool no_info = false; // to check if the arc with the best MI has 
                  // MI = 0.0--> in that case, no continue 
                  // learning the tree structure.   

    /* a up triangular matrix which contains the MI (X,Y) values*/
    /* of the variables of the program*/
    
    for (j=0;j<m_problem_size;j++)
    {
        for ( k=0;k<m_problem_size;k++)
            m_mi[j][k] = (double)0.0;
    }

    /* a boolean double matrix containing if there is an*/
    /* undirected path between two nodes */
    /* between i and i there exists an undirected path*/
    for (j=0;j<m_problem_size;j++)
    {
        for (l=0;l<m_problem_size;l++){
            m_upaths[j][l] = false;
            m_edges[j][l] = false;
        }
            
    }
    for (l=0;l<m_problem_size;l++)
        m_upaths[l][l] = true;


    for (i=0;i<m_problem_size;i++)
    {   
        for (j=i+1;j<m_problem_size;j++)
        {
            m_mi[i][j] = ComputeMI2(i,j,population);
			
        }
    }

    InitBayesianNetwork();

    /*search for the biggest MI and go inducing the BN=Tree of*/
    /*PROBLEM_SIZE-1 arcs*/
    while((withnocycles<(m_problem_size-1)) && (no_info == false))
    {
        max_mi = (double)0.0;

        for (i=0;i<m_problem_size;i++)
        {
            for (j=i+1;j<m_problem_size;j++) /*no undirected path between i and j*/
            {
                if (m_upaths[i][j]==false && m_mi[i][j]>=max_mi)
                {
                    max_i = i;
                    max_j = j;
                    max_mi = m_mi[i][j];
                }
            }
        }

        // The best arc has MI = 0 and the tree learn process must be stopped
        if (max_mi == (double)0.0)
        {
            no_info = true;
            //printf("max mutual information is 0000000000000000000000000000000000000000000000000000000000000000000000000");
        }

        m_mi[max_i][max_j] = (double)(0.0);
        
        // check if the MI of the 'best' arc is not 0.0;-->in this case, no continue learning the tree.
        // check if the edge can be added not to create cycles:
        // no directed paths from i to j, j is no parent of i;
        // no already arc j-->i.

        if ((no_info==false) && (!m_upaths[max_i][max_j]))//&& (m_paths[max_j][max_i]==0))
        {
        	//printf("max mi %f max_i %d max_j %d\n",max_mi, max_i,max_j);
            withnocycles++;

            // The undirected paths of the Bayesian 
            // network are updated. The nodes that can be accesed 
            // from i, they can be now be accesed from j, and viceversa. 

            m_edges[max_i][max_j]=true;
            m_edges[max_j][max_i]=true;

            m_upaths[max_i][max_j]=true;
            m_upaths[max_j][max_i]=true;

            for (l=0;l<m_problem_size;l++)
            {
                if (m_upaths[l][max_i]==true || m_upaths[max_i][l]==true)
                {
                    m_upaths[l][max_j]=true;
                    m_upaths[max_j][l]=true;
                }
                if (m_upaths[l][max_j]==true || m_upaths[max_j][l]==true)
                {
                    m_upaths[l][max_i]=true;
                    m_upaths[max_i][l]=true;
                }
            }
            
            // Update the undirected paths of inderectly implicated nodes. 
            for (l=0;l<m_problem_size;l++)
            {
                if (m_upaths[l][max_i]==true || m_upaths[max_i][l]==true)
                {   
                    for (r=0;r<m_problem_size;r++)
                    {
                        if (m_upaths[r][max_i]==true || m_upaths[max_i][r]==true)
                        {   
                            m_upaths[l][r]=true;
                            m_upaths[r][l]=true;
                        }
                    }
                }

                if (m_upaths[l][max_j]==true || m_upaths[max_j][l]==true)
                {
                    for (r=0;r<m_problem_size;r++)
                    {
                        if (m_upaths[r][max_j]==true || m_upaths[max_j][r]==true)
                        {   
                            m_upaths[l][r]=true;
                            m_upaths[r][l]=true;
                        }
                    }
                }           
            } 
        }

    }

   
    Ordenatu(0,m_edges);

   
}


void CBayesianNetwork::printStruct() 
{ 
	cout<<"here"<<endl;
	/*
	 char gen[5]; 
	char filename[40]; 
	fstream structFile; 
	filename[0]=0; 
	strcat(filename,"struct"); 
	itoa(GEN_NUM,gen,10); 
	strcat(filename, gen); 
	strcat(filename, ".eda"); 
	
	structFile.open(filename, fstream::out); 
	*/
	// Estructura como arcos (padre->hijo). En el EDA se guarda al reves 
	
	for (int i=0; i<m_problem_size; i++)
	{ 
		if (m_parents[i] != NULL) 
		{ 
			for (int j=0; j<m_problem_size; j++)
			{      
				if (m_parents[i][j] == true) 
//					structFile << j+1 << " " << i+1 << endl;
					cout << j << " " << i << endl;

			} 
		} 
	} 
 // structFile.close(); 
} 
void CBayesianNetwork::Ordenatu(int pos, bool**m_edges)
{
 	for (int w=0;w<m_problem_size;w++){
 	    if (m_edges[pos][w]==true){
 	    	m_edges[w][pos]=false;
 		   Add(w, pos);
 		   Ordenatu(w,m_edges);
 	    }
 	}
 }

double CBayesianNetwork::ComputeMI2(int bat,int bi,CPopulation * population)
{
	int i,j;
	for (i=0;i<m_problem_size;i++)
	{
		m_pbat[i]=1;
		m_pbi[i]=1;
		for (j=0;j<m_problem_size;j++)
		{
			m_pbatbi[i][j]=1;
		}
	}
	
	
	
	for (int r=0;r<m_sel_size;r++)
	{
		m_pbat[population->m_individuals[r]->m_solution[bat]]++;
		m_pbi[population->m_individuals[r]->m_solution[bi]]++;
		m_pbatbi[population->m_individuals[r]->m_solution[bat]][population->m_individuals[r]->m_solution[bi]]++;
	}
	
	int st1=2;
	int st2=2;
	
    for (i=0;i<st1;i++) /*para bat*/
    {
		m_pbat[i] = m_pbat[i]/(double)(m_sel_size + st1);//laplace correction
		m_pbi[i] = m_pbi[i]/(double)(m_sel_size + st2);
        for (j=0;j<st2;j++)  /*para bi*/
        {
			 m_pbatbi[i][j] = m_pbatbi[i][j]/(double)(m_sel_size+ st1);
		}
	}
	
    double mi = (double)0.0;

    for (i=0;i<st1;i++) /*para bat*/
    {
        for (j=0;j<st2;j++)  /*para bi*/
        {
            if (m_pbatbi[i][j]!=(double)0.0 && m_pbat[i]!=(double)0.0 && m_pbi[j]!=(double)0.0)
                mi += m_pbatbi[i][j] * (log((m_pbatbi[i][j])/(m_pbat[i]*m_pbi[j])));
        }
    }
	
    return(mi);
}
double CBayesianNetwork::ComputeMI(int bat,int bi,int**&cases)
{

    double pbat = (double)0.0;
    double pbi = (double)0.0;
    double pbatbi = (double)0.0;
    double mi = (double)0.0;

    for (int i=0;i<2;i++) /*para bat*/
    {
        for (int j=0;j<2;j++)  /*para bi*/
        {
            //pbat = (double)0.0; pbi = (double)0.0; pbatbi = (double)0.0;
        	pbat = (double)1.0; pbi = (double)1.0; pbatbi = (double)1.0;//laplace correction
            for (int r=0;r<m_sel_size;r++)
            {
                if (cases[r][bat]==i)
                    pbat = pbat + (double)1.0;
                if (cases[r][bi]==j)
                    pbi = pbi + (double)1.0;
                if ((cases[r][bat]==i) && (cases[r][bi]==j))
                    pbatbi = pbatbi + (double)1.0;
            }
            
            //pbat = pbat/(double)(SEL_SIZE);// + PROBLEM_SIZE);//laplace correction
            //pbi = pbi/(double)(SEL_SIZE);//+ PROBLEM_SIZE);//laplace correction
            //pbatbi = pbatbi/(double)(SEL_SIZE);//+ PROBLEM_SIZE);//laplace correction
            
            pbat = pbat/(double)(m_sel_size + 2);//laplace correction
            pbi = pbi/(double)(m_sel_size + 2);//laplace correction
            pbatbi = pbatbi/(double)(m_sel_size+ 2);//laplace correction

            if (pbatbi!=(double)0.0 && pbat!=(double)0.0 && pbi!=(double)0.0)
                mi += pbatbi * (log((pbatbi)/(pbat*pbi)));
        }
    }

    return(mi);
}



/******************************************************
 ******************************************************
                        MIMIC
 ******************************************************
 ******************************************************/


void CBayesianNetwork::Add(int node, int parent)
{
	int i,j,k;

    // Add the arc.
    m_parents[node][parent] = true;

    // The paths of the Bayesian network
    // are updated.

    for(i=0;i<m_problem_size;i++)
        for(j=0;j<m_problem_size;j++)
            if(m_paths[parent][j]>0 && m_paths[i][node]>0)
                m_paths[i][j]+=m_paths[parent][j]*m_paths[i][node];

    // Update the ordering of the nodes.

    if(m_order[node]<m_order[parent])
    {
        // The order of node, its descendants, parent
        // and its ancestors must be updated.

        int jump_parent = 0;// How many positions the
                            // ancestors of parent are moved.

        // Calculate how many positions the
        // descendants of node must be moved.
        int jump_node = 0;
        for(k=m_order[node];k<=m_order[parent];k++)
            if(m_paths[parent][m_ordered[k]]>0) jump_node++;

        // Update the order of the nodes between
        // node and parent (both included).

        for(k=m_order[node];k<=m_order[parent];k++) 
            if(m_paths[parent][m_ordered[k]]>0)
            {
                m_order[m_ordered[k]] += jump_parent;
                jump_node--;
            }
            else 
            {
                m_order[m_ordered[k]] += jump_node;
                jump_parent--;
            }

        // Update the ordered nodes.

        for(k=0;k<m_problem_size;k++) m_ordered[m_order[k]] = k;
    }
}

double CBayesianNetwork::Entropy(int node,int **&cases)
{int x,i;
    int * n_x = new int[2];

    for(x=0;x<2;x++) n_x[x] = 0;

    for(i=0;i<m_sel_size;i++)
        n_x[cases[i][node]]++;

    double entropy = 0;
    for(x=0;x<2;x++)
        if(n_x[x]>0) entropy += n_x[x]*log((double)n_x[x]);

    entropy /= -m_sel_size;
    entropy += log((double)m_sel_size);

    delete [] n_x;

    return entropy;
}

double CBayesianNetwork::Entropy(int node, int parent, int **&cases)
{int x,i,y;
    int ** n_xy = new int*[2];
    for(x=0;x<2;x++) 
        n_xy[x] = new int[2];
    
    for(x=0;x<2;x++)
        for(int y=0;y<2;y++)
            n_xy[x][y] = 0;

    for(i=0;i<m_sel_size;i++)
        n_xy[cases[i][node]][cases[i][parent]]++;

    double entropy = 0;
    for(x=0;x<2;x++)
    {
        double entropy_y = 0;
        int n_x = 0;

        for(y=0;y<2;y++)
            if(n_xy[x][y]>0)
            {
                entropy_y += n_xy[x][y]*log((double)n_xy[x][y]);
                n_x += n_xy[x][y];
            }

        entropy -= entropy_y;
        if(n_x>0) entropy += n_x*log((double)n_x);
    }

    entropy /= -m_sel_size;
    entropy -= log(double(m_sel_size));

    for(x=0;x<2;x++) delete [] n_xy[x];
    delete [] n_xy;

    return entropy;
}
void CBayesianNetwork::InitBayesianNetwork()
{int i,j;

    for(i=0;i<m_problem_size;i++)
    {
        m_order[i] = i;
        m_ordered[i] = i;

        for(j=0;j<m_problem_size;j++)
        {
            m_parents[i][j] = false;
            
            if(i==j) m_paths[i][j] = 1;
            else m_paths[i][j] = 0;
        }
    }   
}


void CBayesianNetwork::Remove(int node, int parent)
{
    // Remove the arc.

    m_parents[node][parent] = false;

    // The paths of the Bayesian network
    // are updated.

    for(int i=0;i<m_problem_size;i++)
        for(int j=0;j<m_problem_size;j++)
            if(m_paths[parent][j]>0 && m_paths[i][node]>0)
                m_paths[i][j]-=m_paths[parent][j]*m_paths[i][node];
}
double CBayesianNetwork::log_fact(int n)
{
    double value = 0;
    for(int i=2;i<n;i++) value += log((double)i);

    return value;
}



void CBayesianNetwork::LearnEBNAB(CPopulation * population)
{
    InitBayesianNetwork();
    
    LearnEBNALocal(population);
    
}


void CBayesianNetwork::LearnEBNALocal(CPopulation * population)
{
    
    
    //******** COMENTADO PARA PROBAR ADD Y m_parents
    
    
    int TimesArcsChanged = 0;

    CalculateA(population);

    
    double max;
    
    do
    {
        TimesArcsChanged++; //To count the number of arcs removed/added
        
        // Find the arc which modification most increases
        // the BIC metric of the Bayesian network.
        
        int max_i = 0;
        int max_j = 0;
        max = INT_MIN;
        
        
        for(int i=0;i<m_problem_size;i++)
            for(int j=0;j<m_problem_size;j++)
                if(m_paths[j][i]==0 && m_A[i][j]>max)
                {
                    
                    //	cout<<"m_A["<<i<<"]["<<j<<"]: "<<m_A[i][j]<<" -- "<<max<<endl;
                    
                    // In order to modify the arc j->i
                    // there cannot be a path from i to
                    // j.
                    
                    max_i = i;
                    max_j = j;
                    max = m_A[i][j];
                }
        
        // If the BIC metric of the Bayesian network can
        // be improved the arc is modified.
        
        //cout<<"max_i,max_j,max: "<<max_i<<", "<<max_j<<", "<<max<<endl;
        
        if(max>0)
        {
            if(!m_parents[max_i][max_j])
            {
                // If there is no arc j->i, it is added.
                
                //ARC_LOG(max_i,max_j,true);
                
                Add(max_i,max_j);
                //cout<<"Creado arco"<<endl;
            }
            else
            {
                // If there is an arc j->i, it is removed.
                
                //ARC_LOG(max_i,max_j,false);
                
                Remove(max_i,max_j);
            }
            //cout<<"Cambia el arco "<<max_i<<","<<max_j<<endl;
            //Actualize the Actual BIC or K2 metric
            m_ActualMetric[max_i] += m_A[max_i][max_j];
            
            //gettimeofday(&cin1,NULL);
            CalculateANode(max_i,population);
            //gettimeofday(&cout1,NULL);
            //cout<<"CalculateANode(in)="<<(cout1.tv_sec-cin1.tv_sec)*1000000+(cout1.tv_usec-cin1.tv_usec)<<endl;
        }
        
    }
    while(max>0);
    
}


void CBayesianNetwork::CalculateANode(int node, CPopulation * population)
{

    for(int i=0;i<m_problem_size;i++){
        if ((i!=node) &&(m_paths[i][node]==0))
        {
            m_parents[node][i] = !m_parents[node][i];
            
            double new_metric= BIC(node,population);
            
            m_parents[node][i] = !m_parents[node][i];
            m_A[node][i] = new_metric - m_ActualMetric[node];
        }
        else
            m_A[node][i] = INT_MIN;
    }

}

void CBayesianNetwork::CalculateA(CPopulation * population)
{
    for(int node=0;node<m_problem_size;node++) {
        m_ActualMetric[node] = BIC(node,population);
        CalculateANode(node,population);
    }        
    
}


double CBayesianNetwork::BIC(int node, CPopulation * population)
{
    int j,k;
    
    //gettimeofday(&Bin,NULL);
    // Calculate the number of parent configurations.
    
    int no_j = 1;
    for(j=0;j<m_problem_size;j++)
        if(m_parents[node][j])
            no_j *= 2;
    
    //cout<<"no_j="<<no_j<<endl;
    
    //gettimeofday(&Bout,NULL);
    //cout<<"Numberofparents."<<(Bout.tv_sec-Bin.tv_sec)*1000000+(Bout.tv_usec-Bin.tv_usec)<<endl;
    
    // Allocate memory for all nijk-s.
    
    //gettimeofday(&Bin,NULL);
    
    int ** nijk = new int*[no_j];
    for(j=0;j<no_j;j++)
    {
        nijk[j] = new int[2];
        for(k=0;k<2;k++) nijk[j][k] = 0;
    }
    
    //gettimeofday(&Bout,NULL);
    //cout<<"Allocate nijk."<<(Bout.tv_sec-Bin.tv_sec)*1000000+(Bout.tv_usec-Bin.tv_usec)<<endl;
    
    // Calculate all nijk-s.
    
    //gettimeofday(&Bin,NULL);
    //cout<<"SEL_SIZE="<<SEL_SIZE<<endl;
    for(j=0;j<m_sel_size;j++)
    {
        // Find the parent configuration for the j-th case.
        
        int parent_configuration = 0;
        for(int parent=0;parent<m_problem_size;parent++)
            if(m_parents[node][parent])
            {
                parent_configuration *= 2;
                parent_configuration += population->m_individuals[j]->m_solution[parent];
            }
        
        // Update the corresponding nijk.
        //cout<<"parent_configuration="<<parent_configuration<<endl;
        
        nijk[parent_configuration][population->m_individuals[j]->m_solution[node]]++;
    }
    
    //gettimeofday(&Bout,NULL);
    //cout<<"Calculate nijk."<<(Bout.tv_sec-Bin.tv_sec)*1000000+(Bout.tv_usec-Bin.tv_usec)<<endl;
    
    
    //gettimeofday(&Bin,NULL);
    
    // Calculate the BIC value.
    
    double bic = 0;
    
    for(j=0;j<no_j;j++)
    {
        int nij = 0;
        for(k=0;k<2;k++)
        {
            nij += nijk[j][k];
            
            //For rounding problems...
            if (nijk[j][k]!=0){
                //cout<<"Sumo: "<<nijk[j][k]*log(nijk[j][k])<<endl;
                bic += nijk[j][k]*log(nijk[j][k]);
            }
        }
        
        //For rounding problems...
        if (nij!=0)
            bic -= nij*log(nij);
    }
    bic -= log(m_sel_size)*no_j*(2-1)/2;
    
    //gettimeofday(&Bout,NULL);
    //cout<<"Calculate BIC."<<(Bout.tv_sec-Bin.tv_sec)*1000000+(Bout.tv_usec-Bin.tv_usec)<<endl;
    
    
    // Free the memory allocated for the nijk-s.
    //cout << "Comienza a liberar"<<endl;
    for(j=0;j<no_j;j++){
        delete [] nijk[j];
        //cout<<"Liberando "<<j<<" de "<<no_j<<endl;
    }
    delete [] nijk;
    //cout <<"Termina de liberar"<<endl;
    return bic;
}
