// BayesianNetwork.h: interface for the CBayesianNetwork class.
//
// Description:
//      The class which handles Bayesian networks.
//
// Author:  Ramon Etxeberria
// Date:    1999-09-25
//
// Note:
//      The information about the problem must be initialized
//      before any  Bayesian network is created.

#ifndef _BAYESIAN_NETWORK_
#define _BAYESIAN_NETWORK_
#include "Population.h"
#include "Individual.h"
#ifdef PARALLEL
    #include "Parallel.h"
#endif

// The learning type (i.e. the EDA type).
#define UMDA 0
#define EBNA_B 1
#define EBNA_LOCAL 2
#define PBIL 3
#define BSC 4
#define TREE 5
#define MIMIC 6
#define EBNA_K2 7
#define EBNA_PC 8
#define EBNA_GLOBAL 9
#define BN_FIXED 10
#define PMA 11
#define MALLOWS 12
#define GMALLOWS 13

// The simulation type (i.e. PLS is the simplest).
#define PLS 0
#define PLS_ALL_VALUES_1 1
#define PLS_ALL_VALUES_2 2
#define PLS_CORRECT		 3
#define PENALIZATION	 4

// The selection type.
#define RANGE_BASED 0
#define TRUNCATION 1

// Scores for the EBNA-local learning types
#define BIC_SCORE 0
#define K2_SCORE 1


class CBayesianNetwork  
{
public:
    // The constructor. It creates an arcless Bayesian
    // network which represents a uniform probability
    // distribution.
    CBayesianNetwork(int problem_size, int sel_size, int learning, int sampling);

    // The destructor.
    virtual ~CBayesianNetwork();

    // It learns the Bayesian network from the given cases.
    void Learn(CPopulation* population);

    // It creates a new individual simulating the Bayesian
    // network.
    void Simulate(int * solution);
    
    // The BIC metric for the local structure (EBNA BIC) represented by
    // m_parents[node].
    double BIC(int node, CPopulation * population);
	
	// Matrixes storing the improvement of arc modifications.
    // m_A[i][j] represents the gain which could be obtained
    // when adding/removing the arc j->i when it is absent/present.
    // m_ActualMetric[node] stores the actual value of the score of 
    // the Bayesian network
    long double ** m_A;
    double *m_ActualMetric;


    double log_fact(int n);

    int ** m_cases;
    
    int m_problem_size;
    int m_sel_size;
    int m_learning;
    int m_sampling;

private:
    // Adjacency matrix representing the structure of
    // the Bayesian network. If m_parents[i][j] is true
    // the there is an arc j->i in the Bayesian network.
    bool ** m_parents;

    // The conditional probability distributions of the
    // bayesian network. m_probs[i][j*(r_i-1)+k] represents the
    // probability of i being in its k-th state conditiones
    // to its parent nodes being in their j-th configuration 
    // (r_i is the number of possible states that i can take).
    double ** m_probs;

    // The matrix which stores the number of paths between
    // two nodes. m_paths[i][j] represents the number of
    // paths from j to i. m_paths[i][i] is always 1.
    int ** m_paths;

    // The topologycal order of the nodes. m_order[i]
    // represents the topologycal order of i.
    int * m_order;

    // The nodes of the Bayesian network ordered according
    // to their topologycal order.
    int * m_ordered;
    
    //data structures to learn a tree.
    double **m_mi;
    bool ** m_upaths;
    bool ** m_edges;
    double* m_pbat;
    double* m_pbi;
    double** m_pbatbi;

    // It calculates the m_A matrix of the current Bayesian
    // networks.
    void CalculateA(CPopulation * population);
    
    // It calculates the m_A[node] values of the current
    // Bayesian network.
    void CalculateANode(int node, CPopulation * population);
    
    // It sets the structure of the Bayesian network to
    // an arcless graph.
    void InitBayesianNetwork();

    void Ordenatu(int pos,bool**m_upaths);

	void Print_BayesianNetworkEdges(bool** m_edges);
	
	void printStruct();

    // It learns the structure of the Bayesian network using
    // the local search algorithm.
    void LearnEBNALocal(CPopulation * population);
    
    // It learns the structure of the Bayesian network using
    // the B algorithm.
    void LearnEBNAB(CPopulation * population);
    
    // It learng the structure of the Tree by the MWST method 
    // of Chow and Liu.
    void LearnTree(CPopulation * population);
	
	// The empirical entropy of node given parent.
    double Entropy(int node, int parent, int **&cases);

    // The empirical entropy of node.
    double Entropy(int node, int **&cases);

    // It adds the arc parent->node to the Bayesian network
    // and updates all the internal data.
    void Add(int node, int parent);

    // It removes the arc parent->node from the Bayesian
    // network and updates all the internal data.
    void Remove(int node, int parent);

    // Compute the MI value between two variables in selected individuals
    double ComputeMI(int bat,int bi,int**&cases);
	
    double ComputeMI2(int bat,int bi,CPopulation * population);

    // It calculates the probabilities of the Bayesian network.
    void LearnProbabilities(CPopulation * population);

    // It returns the conditional probability distribution
    // of the orderede_node-th gene conditioned to the
    // states that its parent nodes have in instance.
    double * Probabilities(int ordered_node,int * instance);

};

#endif
