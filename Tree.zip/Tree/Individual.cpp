/*
 *  Individual.cpp
 *  TreeforGGP
 *
 *  Created by Josu Ceberio Uribe on 26/05/16.
 *  Copyright 2016 University of the Basque Country. All rights reserved.
 *
 */

#include "Individual.h"




// The constructor of the class individual.
CIndividual::CIndividual(long length)
{
	m_size = length;
	m_solution = new int[m_size];
    m_value=LONG_MAX;
    
}

// The descructor of the class individual
CIndividual::~CIndividual()
{
	delete [] m_solution;
	m_solution=NULL;
}

