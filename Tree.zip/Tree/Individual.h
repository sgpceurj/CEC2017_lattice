/*
 *  Individual.h
 *  TreeforGGP
 *
 *  Created by Josu Ceberio Uribe on 26/05/16.
 *  Copyright 2016 University of the Basque Country. All rights reserved.
 *
 */

#ifndef _INDIVIDUAL_
#define _INDIVIDUAL_

#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <limits.h>

class CIndividual
{
public:

    // The variable storing the solutions score value.
    long m_value;
    
    // The genes of the individual.
    int * m_solution;
    
    // The size of the individual
    long m_size;
    
    // The constructor. The constructed individual has all zeroes as its genes.
	CIndividual(long length);

	// The destructor. It frees the memory allocated at the construction of the individual.
	virtual ~CIndividual();
};

#endif
