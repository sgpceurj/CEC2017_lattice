//
//  ParameterSetting.h
//  TreeforGGP
//
//  Created by Josu Ceberio Uribe on 02/11/16.
//  Copyright © 2016 University of the Basque Country. All rights reserved.
//
#include "Individual.h"
#include "Population.h"
#include <string.h>
#ifndef ParameterSetting_h
#define ParameterSetting_h

#define MAX_LONG_INTEGER 429496729500000
#define MIN_LONG_INTEGER -429496729500000
#define EQUAL(A,B) ( (A == B) ? 1 : 0)
//#define PRINT_LOG 0
#define KALIMERO 1 //Activated when running on kalimero.
#define MODEL_TYPE 5 // TREE
//#define MODEL_TYPE 1 // EBNA


// Verbose option. 1- Activated, 0- Deactivated
int VERBOSE=0;

// Size of the problem.
long PROBLEM_SIZE;

// Number of evaluations performed.
long int EVALUATIONS = 0;

// Convergence evaluation of the best fitness.
long int CONVERGENCE_EVALUATIONS = 0;

// Maximum number of evaluations allowed performed.
long int MAX_EVALUATIONS = 1000000;

// Name of the file where the result will be stored.
char RESULTS_FILENAME[50];

// Name of the file where the instances is stored.
char INSTANCE_FILENAME[50];

// The seed asigned to the process
int SEED;

// Population size.
int POP_SIZE=2000;

// Selection pool size.
int SEL_SIZE;

// Offspring pool size.
int OFF_SIZE=1000;

// Instance of the GPP problem.
GPP * PROBLEM;

// Best individual found so far during the optimization process.
CIndividual * BEST;

// Population of solutions.
CPopulation * POP;

// Auxiliary variable for sampling.
int * SOLUTION;

/*
 * Get next command line option and parameter
 */
int GetOption (int argc, char** argv, char* pszValidOpts, char** ppszParam)
{
    
    static int iArg = 1;
    char chOpt;
    char* psz = NULL;
    char* pszParam = NULL;
    
    if (iArg < argc)
    {
        psz = &(argv[iArg][0]);
        
        if (*psz == '-' || *psz == '/')
        {
            // we have an option specifier
            chOpt = argv[iArg][1];
            
            if (isalnum(chOpt) || ispunct(chOpt))
            {
                // we have an option character
                psz = strchr(pszValidOpts, chOpt);
                
                if (psz != NULL)
                {
                    // option is valid, we want to return chOpt
                    if (psz[1] == ':')
                    {
                        // option can have a parameter
                        psz = &(argv[iArg][2]);
                        if (*psz == '\0')
                        {
                            // must look at next argv for param
                            if (iArg+1 < argc)
                            {
                                psz = &(argv[iArg+1][0]);
                                if (*psz == '-' || *psz == '/')
                                {
                                    // next argv is a new option, so param
                                    // not given for current option
                                }
                                else
                                {
                                    // next argv is the param
                                    iArg++;
                                    pszParam = psz;
                                }
                            }
                            else
                            {
                                // reached end of args looking for param
                            }
                            
                        }
                        else
                        {
                            // param is attached to option
                            pszParam = psz;
                        }
                    }
                    else
                    {
                        // option is alone, has no parameter
                    }
                }
                else
                {
                    // option specified is not in list of valid options
                    chOpt = -1;
                    pszParam = &(argv[iArg][0]);
                }
            }
            else
            {
                // though option specifier was given, option character
                // is not alpha or was was not specified
                chOpt = -1;
                pszParam = &(argv[iArg][0]);
            }
        }
        else
        {
            // standalone arg given with no option specifier
            chOpt = 1;
            pszParam = &(argv[iArg][0]);
        }
    }
    else
    {
        // end of argument list
        chOpt = 0;
    }
    
    iArg++;
    
    *ppszParam = pszParam;
    return (chOpt);
}

/*
 * Help command output.
 */
void usage(char *progname)
{
    cout << "Usage: ContrainedEDA -i <instance_name>  -o <results_filename> -s <seed> -p <<population_size>> -s <<selection_size>> -f <<offpspring_size>> -v <<verbose_option>>" <<endl;
    cout <<"   -i File name of the instance."<<endl;
    cout <<"   -o Name of the file to store the results."<<endl;
    cout <<"   -s Seed to be used for pseudo-random numbers generator."<<endl;
    cout <<"   -p Parents population size (Def. 100)."<<endl;
    cout <<"   -l Selection pool size (Def. 50)."<<endl;
    cout <<"   -f Offsprings population size (Def. 100)."<<endl;
    cout <<"   -v Activates verbose option (0 or 1)."<<endl;
}

/*
 * Obtaint the execution parameters from the command line.
 */
bool GetParameters(int argc,char * argv[])
{
    char c;
    if(argc==1)
    {
        usage(argv[0]);
        return false;
    }
    char** optarg;
    optarg = new char*[argc];
    while ((c = GetOption (argc, argv, ":h:s:o:i:p:l:f:v:t:",optarg)) != '\0')
    {
        switch (c)
        {
            case 'h' :
                usage(argv[0]);
                return false;
                break;
                
            case 's' :
                SEED = atoi(*optarg);
                srand(SEED);
                break;
                
            case 'o' :
                strcpy(RESULTS_FILENAME, *optarg);
                break;
                
            case 'i':
                strcpy(INSTANCE_FILENAME, *optarg);
                break;
                
            case 'p':
                POP_SIZE=atoi(*optarg);
                break;
                
            case 'l':
                SEL_SIZE=atoi(*optarg);
                break;
                
            case 'f':
                OFF_SIZE=atoi(*optarg);
                break;
                
            case 'v':
                VERBOSE=atoi(*optarg);
                break;
                
            default:
                cout<<"Wrong parameter specification... "<<endl;
                exit(1);
        }
    }
    
    delete [] optarg;
    return true;
}

#endif /* ParameterSetting_h */
