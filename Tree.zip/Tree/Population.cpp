/*
 *  Population.cpp
 *  TreeforGGP
 *
 *  Created by Josu Ceberio Uribe on 26/05/16.
 *  Copyright 2016 University of the Basque Country. All rights reserved.
 *
 */

#include "Population.h"


// Constructor function
CPopulation::CPopulation(int pop_size, int off_size, long solution_size)
{
    m_pop_size=pop_size;
    m_off_size=off_size;
    m_individuals.resize(m_pop_size+m_off_size);
    m_problem_size=solution_size;
    
    //Initialize population with empty solutions
    for (int i=0;i<m_pop_size+m_off_size;i++)
    {
        m_individuals[i]= new CIndividual(solution_size);
    }
}

// Destructor function
CPopulation::~CPopulation()
{
    for (int i=0;i<m_pop_size+m_off_size;i++)
    {
        delete m_individuals[i];
    }
    m_individuals.clear();
}

// Function to set an individual in a specific position of the population
void CPopulation::SetToPopulation(int * solution, int index, long fitness)
{
    memcpy( m_individuals[index]->m_solution, solution, sizeof(int)*m_problem_size);
    m_individuals[index]->m_value=fitness;
    m_individuals[index]->m_size=m_problem_size;
}


// Sorts the individuals in the population in ascending order of the fitness value.
// returns true if the best solution was outperformed.
bool CPopulation::SortPopulation(CIndividual * best)
{
    sort(m_individuals.begin(), m_individuals.begin()+m_pop_size+m_off_size, Better_min);
    
    if (m_individuals[0]->m_value<best->m_value){
        best->m_value=m_individuals[0]->m_value;
        best->m_size=m_individuals[0]->m_size;
        memcpy(best->m_solution, m_individuals[0]->m_solution, sizeof(int)*m_individuals[0]->m_size);
        return true;
    }
    else{
        return false;
    }
}

/*
 * Prints the current population.
 */
void CPopulation::Print(int samples)
{
    int i;
    for(i=0;i<samples; i++){
        printf("ID: %d, %ld: ",i,m_individuals[i]->m_value);
        //for (j=0;j<m_problem_size;j++){
        //    printf("%d, ",m_individuals[i]->m_solution[j]);
        //}
        printf("\n");
    }
}

// Checks if the given solution is already contained in the first "size" solutions in the population.
bool CPopulation::Exists( int * solution, long problem_size, int size){
    for (int i=0;i<size;i++){
        if (memcmp(solution,m_individuals[i]->m_solution,sizeof(int)*problem_size)==0){
            return true;
        }
    }
    return false;
}
