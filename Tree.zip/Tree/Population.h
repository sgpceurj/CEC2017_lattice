/*
 *  Population.h
 *  TreeforGGP
 *
 *  Created by Josu Ceberio Uribe on 26/05/16.
 *  Copyright 2016 University of the Basque Country. All rights reserved.
 *
 */

#ifndef _POPULATION_
#define _POPULATION_

#include <stdlib.h>
#include <stdio.h>
#include <vector>
#include <string.h>
#include <algorithm>
#include "Individual.h"

using namespace std;

class CPopulation
{
    
public:

    struct Better_min{
        bool operator()(CIndividual * a, CIndividual * b) const{
            return a->m_value<b->m_value;
        }
    } Better_min;
    
    
    // Vector of individuals that constitute the population.
    vector<CIndividual *> m_individuals;
    
    // Size of the population
    int m_pop_size;
    
    // Size of the pool of sampled offsprings.
    int m_off_size;
    
    // Size of the solutions
    long m_problem_size;
    
	// The constructor. It creates an empty list.
    CPopulation(int pop_size, int off_size, long solution_size);
    
	// The destructor.
	virtual ~CPopulation();
    
    // Function to set an individual in a specific position of the population
    void SetToPopulation(int * solution, int index, long fitness);
    
    // Sorts the individuals in the population in ascending order of the fitness value.
    // returns true if the best solution was outperformed.
    bool SortPopulation(CIndividual * best);
   
    // Prints the current population.
    void Print(int samples);
    
    // Checks if the given solution is already contained in the first "size" solutions in the population.
    bool Exists( int * solution, long problem_size, int size);
private:
    
};

#endif


