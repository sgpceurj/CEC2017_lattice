//
//  main.cpp
//  TreeforGGP
//
//  Created by Josu Ceberio Uribe on 02/11/16.
//  Copyright © 2016 University of the Basque Country. All rights reserved.
//
#include <sys/time.h>
#include <iostream>
#include "GPP.hpp"
#include "ParameterSetting.h"
#include "Individual.h"
#include "BayesianNetwork.h"
#include "Population.h"
#include <math.h>
#include <list>

/*
 * Generates a random binary solution of size 'n' in the given array with equal number of 0s and 1s.
 */
void GenerateRandomBinaryBalanced(int * solution, long n);

/*
 * Given a population of solutions, it calculates the parameters of the probabilistic model.
 */
void Learn(CPopulation * pop, int num_solutions_to_learn);

/*
 * Samples new solutions from the probabilistic model.
 */
int Sample(CBayesianNetwork * network, CPopulation * pop, int num_samples);

/*
 * Prints in the standard output the 'size' elements of the given array..
 */
void PrintArray(int * array, long size);

/*
 * Prints in the standard output the 'size' elements of the given array..
 */
void PrintArray(float * array, long size);

/*
 * Prints in the standard output the 'size' elements of the given array..
 */
void PrintArray(long double * array, long size);

/*
 * Prints in the standard output given matrix.
 */
void PrintMatrix(float** matrix, long length, int length2);

/*
 * Initializes the order of variables in the model
 */
void Initialize_Order(void);

/*
 * Main function.
 */
int main(int argc, char * argv[]) {
    
    //0. Initial timing.
    struct timeval tim;
    gettimeofday(&tim, NULL);
    double t1=tim.tv_sec+(tim.tv_usec/1000000.0);
    
    // ==================================================================================
    //1. Read the parameters
    if (VERBOSE)
        cout<<"1. Reading the parameters..."<<endl;
    
    if(!GetParameters(argc,argv))
        return -1;
    
    // ==================================================================================
    //2. Variable initializations and instance reading
    
    if (VERBOSE)
        cout<<"2. Reading instance "<<INSTANCE_FILENAME<<" and initializing variables..."<<endl;
    
    PROBLEM = new GPP();
    PROBLEM_SIZE= PROBLEM -> Read(INSTANCE_FILENAME);
    POP_SIZE=10*PROBLEM_SIZE;
    MAX_EVALUATIONS=100*PROBLEM_SIZE*PROBLEM_SIZE;
    
    SEL_SIZE=POP_SIZE/2;
    OFF_SIZE=POP_SIZE;
    
    BEST= new CIndividual(PROBLEM_SIZE);
    
    // ==================================================================================
    //3. Initializing Constrained EDA.
    
    if (VERBOSE)
        cout<<"3. Initializing Constrained EDA..."<<endl;
    
    //3.1. Initialize population of solutions and initialize order.
    POP= new CPopulation(POP_SIZE, OFF_SIZE, PROBLEM_SIZE);
    SOLUTION= new int[PROBLEM_SIZE];
    for(int i=0;i<POP_SIZE;i++)
    {
        //Create random individual
        GenerateRandomBinaryBalanced(SOLUTION,PROBLEM_SIZE);
        POP->SetToPopulation(SOLUTION, i, PROBLEM->Evaluate(SOLUTION));
        EVALUATIONS++;
    }
    
    
    POP->SortPopulation(BEST);
    //POP->Print(POP_SIZE);
    
    //3.2. Create probability model structures.
    // The Bayesian network estimated from the selected individuals.
    CBayesianNetwork * BAYESIAN_NETWORK;
    if (MODEL_TYPE==5){
        BAYESIAN_NETWORK=new CBayesianNetwork(PROBLEM_SIZE,SEL_SIZE, TREE,PLS_CORRECT);
    }
    else{
        BAYESIAN_NETWORK=new CBayesianNetwork(PROBLEM_SIZE,SEL_SIZE, EBNA_B,PLS_CORRECT);
    }
    
    
    // ==================================================================================
    //4. Constrained EDA execution
    if (VERBOSE)
        cout<<"4. Running Constrained EDA..."<<endl;
    int iteration=0;
    int non_improvement=0;
    while (EVALUATIONS<MAX_EVALUATIONS){
        
        // 4.1. Learning
        BAYESIAN_NETWORK->Learn(POP);
        
        
        // 4.2. Sampling
        //cout<<"Sampling..."<<endl;
        if ((EVALUATIONS+OFF_SIZE)<MAX_EVALUATIONS){
            EVALUATIONS+= Sample(BAYESIAN_NETWORK, POP, OFF_SIZE);
        }
        else{
            EVALUATIONS+= Sample(BAYESIAN_NETWORK,POP, (int)(MAX_EVALUATIONS-EVALUATIONS));
        }
        non_improvement++;
        // 4.3. Update indicators and print logs.
        if (POP->SortPopulation(BEST)==true)
        {
            CONVERGENCE_EVALUATIONS=EVALUATIONS;
#ifdef PRINT_LOG
            cout<<"ITER: "<<iteration<<" , BS: "<<BEST->m_value<<" , EV: "<<EVALUATIONS<<" , REM: "<<MAX_EVALUATIONS-EVALUATIONS<<endl;
            //PrintArray(BEST->m_solution, PROBLEM_SIZE);
#endif
            non_improvement=0;
        }
        
        iteration++;
    }
    
    
    //5. Calculate consumed time and write results in file.
    gettimeofday(&tim, NULL);
    double t2=tim.tv_sec+(tim.tv_usec/1000000.0);
    cout<<"Final score: "<<BEST->m_value<<endl;
    cout<<"Time spent: "<<t2-t1<<endl;
    
#ifndef KALIMERO
    //Local executions
    FILE * test= fopen("/Users/Josu/Dropbox/EHU/Research/Publications/CEC2017/Lattice/Experiments/temp_results.csv","r");
    FILE * result_file= fopen("/Users/Josu/Dropbox/EHU/Research/Publications/CEC2017/Lattice/Experiments/temp_results.csv","a+");
    if (test==NULL){
        fprintf(result_file,"\"Instance\";\"Repetition\";\"Algorithm\";\"Fitness\";\"Time\"\n");
    }
    if (MODEL_TYPE==5)
        fprintf(result_file,"\"%s\";%d;\"%s\";%ld;%.3f\n",INSTANCE_FILENAME,SEED,"TREE_new",BEST->m_value,t2-t1);
    else
        fprintf(result_file,"\"%s\";%d;\"%s\";%ld;%.3f\n",INSTANCE_FILENAME,SEED,"EBNA",BEST->m_value,t2-t1);
    
    fclose(result_file);
    fclose(test);
#endif
    
#ifdef KALIMERO
    //In Kalimero
    FILE * result_file= fopen("./scratch_results.csv","w");
    //fprintf(result_file,"\"Instance\";\"Repetition\";\"Algorithm\";\"Fitness\";\"Time\"\n");
    if (MODEL_TYPE==5)
        fprintf(result_file,"\"%s\";%d;\"%s\";%ld;%.3f\n",INSTANCE_FILENAME,SEED,"TREE_new",BEST->m_value,t2-t1);
    else
        fprintf(result_file,"\"%s\";%d;\"%s\";%ld;%.3f\n",INSTANCE_FILENAME,SEED,"EBNA",BEST->m_value,t2-t1);
    fclose(result_file);
#endif

    
    //6. Delete structures
   
    delete [] SOLUTION;
    delete POP;
    delete BEST;
    return 0;
}

/*
 * Generates a random binary solution of size 'n' in the given array with equal number of 0s and 1s.
 */
void GenerateRandomBinaryBalanced(int * solution, long n)
{
    std::fill_n(solution,n,0);
    int i=0; // In order to avoid symmetry in the problem, we fix in the first position always 0.
    int pos;
    while (i<(n/2)){
        pos=1+(rand()%(n-1));// In order to avoid symmetry in the problem, we fix in the first position always 0.
        if (solution[pos]==0){
            solution[pos]=1;
            i++;
        }
    }
}


/*
 * Samples new solutions from the probabilistic model.
 */
int Sample(CBayesianNetwork * network, CPopulation * pop, int num_samples){
    //  cout<<"num samples: "<<num_samples<<endl;
    // pop->Print(num_samples);
    int i;
    int * SOLUTION = new int [PROBLEM_SIZE];
    
    for (i=0;i<num_samples;i++){
        
        network->Simulate(SOLUTION);
        if (pop->Exists(SOLUTION, PROBLEM_SIZE, POP_SIZE+i)==false){
            //save new solution in the population
            //    PrintArray(SOLUTION, PROBLEM_SIZE);
            pop->SetToPopulation(SOLUTION, pop->m_pop_size+i, PROBLEM->Evaluate(SOLUTION));
        }
        else{
            i--;
        }
    }
    delete [] SOLUTION;
    return num_samples;
}


/*
 * Prints in the standard output the 'size' elements of the given array..
 */
void PrintArray(int * array, long size)
{
    for (long i=0;i<size;i++){
        cout<<array[i]<<" ";
    }
    cout<<" "<<endl;
}

/*
 * Prints in the standard output the 'size' elements of the given array..
 */
void PrintArray(float * array, long size)
{
    for (long i=0;i<size;i++){
        cout<<array[i]<<" ";
    }
    cout<<" "<<endl;
}

/*
 * Prints in the standard output the 'size' elements of the given array..
 */
void PrintArray(long double * array, long size)
{
    for (long i=0;i<size;i++){
        cout<<array[i]<<" ";
    }
    cout<<" "<<endl;
}

/*
 * Prints in the standard output given matrix.
 */
void PrintMatrix(float** matrix, long length, int length2)
{
    int i,j;
    for (i=0;i<length;i++)
    {
        for (j=0;j<length2;j++)
        {
            printf("%.2f\t",matrix[i][j]);
        }
        printf("\n");
    }
    printf("\n");
}
