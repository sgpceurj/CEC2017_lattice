//
//  GPP.cpp
//  ConstrainedEDAforGPP
//
//  Created by Josu Ceberio Uribe on 02/11/16.
//  Copyright © 2016 University of the Basque Country. All rights reserved.
//

#include "GPP.hpp"

// Class constructor.
GPP::GPP()
{
    m_vertex_num=0;
    m_edges_num=0;
    m_type=0;
}

// Class destructor.
GPP::~GPP()
{
    for (int i=0;i<m_vertex_num;i++){
        delete [] m_graph_structure[i];
        delete [] m_edge_weights[i];
    }
    delete [] m_graph_structure;
    delete [] m_edge_weights;
}

// Read GPP instance from file.
long GPP::Read(char filename[50])
{
    FILE *file;
    file=fopen(filename, "r");
    //fscanf(file,"%ld %ld %d",&m_vertex_num,&m_edges_num, &m_type);
    fscanf(file,"%ld %ld",&m_vertex_num,&m_edges_num);
    
    //Initialize graph structure matrix.
    int i,j;
    m_graph_structure= new int*[m_vertex_num];
    m_edge_weights= new int*[m_vertex_num];
    for (i=0;i<m_vertex_num;i++){
        m_graph_structure[i]= new int[m_vertex_num];
        m_edge_weights[i]= new int[m_vertex_num];
        for (j=0;j<m_vertex_num;j++){
            m_graph_structure[i][j]=0;
            m_edge_weights[i][j]=0;
        }
    }
    
    // read and parse graph structure from file to matrix.
    //Read the whole file to get the dimensions of data.
    char line[5096];
    char * chop;
    const char * delimiter=" ";
    i=0;
    fgets(line, 5096, file);
    //Read the whole file to get the dimensions of data.
    while (fgets(line, 5096, file)!=NULL){
        if(line[0]!='\n'){
            chop=strtok(line,delimiter);
            j=0;
            while(chop!=NULL){
                m_graph_structure[i][atoi(chop)-1]=1;
                m_edge_weights[i][atoi(chop)-1]=1;
                chop=strtok(NULL,delimiter);
                j++;
            }
            
        }
        i++;
        
    }
    fclose(file);
    
    //print graph structure.
   /*  for (i=0;i<m_vertex_num;i++){
        for (j=0;j<m_vertex_num;j++){
            printf("%d ",m_graph_structure[i][j]);
           // printf("%d ",m_edge_weights[i][j]);
        }
        printf("\n");
    }
    */
    
    return m_vertex_num;
    
}

// Create a random GPP instance.
long GPP::Random(int size)
{
    m_vertex_num=size;
    
    //Initialize graph structure matrix.
    int i,j;
    m_graph_structure= new int*[m_vertex_num];
    m_edge_weights= new int*[m_vertex_num];
    for (i=0;i<m_vertex_num;i++){
        m_graph_structure[i]= new int[m_vertex_num];
        m_edge_weights[i]= new int[m_vertex_num];
        for (j=0;j<m_vertex_num;j++){
            m_graph_structure[i][j]=rand()%2;
            m_edge_weights[i][j]=rand()%10;
        }
    }
    
    return m_vertex_num;
    
}

// This function calculates the score of the given solution for the GPP instance.
long GPP::Evaluate(int * solution)
{
    int i,j;
    long score=0;
    for (i=0;i<m_vertex_num;i++){
        for (j=0;j<m_vertex_num;j++){
            score+=(solution[i]*(1-solution[j])*m_edge_weights[i][j]);
        }
    }
    return score;
}
