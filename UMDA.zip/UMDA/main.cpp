//
//  main.cpp
//  UMDAforGPP
//
//  Created by Josu Ceberio Uribe on 09/11/16.
//  Copyright © 2016 University of the Basque Country. All rights reserved.
//

#include <sys/time.h>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include "GPP.hpp"
#include "ParameterSetting.h"
#include "Individual.h"
#include "Population.h"
#include <math.h>
#include <list>
#include <string.h>
#include <limits.h>
#include <sstream>


/*
 * Generates a random binary solution of size 'n' in the given array with equal number of 0s and 1s.
 */
void GenerateRandomBinaryBalanced(int * solution, long n);

/*
 * Given a population of solutions, it calculates the parameters of the probabilistic model.
 */
void Learn(CPopulation * pop, int num_solutions_to_learn);

/*
 * Samples new solutions from the probabilistic model.
 */
int Sample(CPopulation * pop, int num_samples);

/*
 * Repairs the solution in order to have same number of 0s and 1s.
 */
bool Repair(int * solution);

/*
 * Prints in the standard output the 'size' elements of the given array..
 */
void PrintArray(int * array, long size);

/*
 * Prints in the standard output the 'size' elements of the given array..
 */
void PrintArray(float * array, long size);

/*
 * Prints in the standard output given matrix.
 */
void PrintMatrix(float** matrix, long length, int length2);

/*
 * Main function.
 */
int main(int argc, char * argv[]) {
    
    //0. Initial timing.
    struct timeval tim;
    gettimeofday(&tim, NULL);
    double t1=tim.tv_sec+(tim.tv_usec/1000000.0);
    
    // ==================================================================================
    //1. Read the parameters
    if (VERBOSE)
        cout<<"1. Reading the parameters..."<<endl;
    
    if(!GetParameters(argc,argv))
        return -1;
    
    // ==================================================================================
    //2. Variable initializations and instance reading
    
    if (VERBOSE)
        cout<<"2. Reading instance "<<INSTANCE_FILENAME<<" and initializing variables..."<<endl;
    
    PROBLEM = new GPP();
    PROBLEM_SIZE= PROBLEM -> Read(INSTANCE_FILENAME);
    //PROBLEM_SIZE= PROBLEM -> Random(100);
    POP_SIZE=10*PROBLEM_SIZE;
    SEL_SIZE=POP_SIZE/2;
    OFF_SIZE=POP_SIZE;
    MAX_EVALUATIONS=100*PROBLEM_SIZE*PROBLEM_SIZE;
    BEST= new CIndividual(PROBLEM_SIZE);
    
    // ==================================================================================
    //3. Initializing Constrained EDA.
    
    if (VERBOSE)
        cout<<"3. Initializing Constrained EDA..."<<endl;
    
    //3.1. Initialize population of solutions.
    POP= new CPopulation(POP_SIZE, OFF_SIZE, PROBLEM_SIZE);
    int * aux= new int[PROBLEM_SIZE];
    for(int i=0;i<POP_SIZE;i++)
    {
        //Create random individual
        GenerateRandomBinaryBalanced(aux,PROBLEM_SIZE);
        POP->SetToPopulation(aux, i, PROBLEM->Evaluate(aux));
        EVALUATIONS++;
    }
    
    delete [] aux;
    POP->SortPopulation(BEST);
   // POP->Print(POP_SIZE);
    
    //3.2. Create probability model structures.
    PROBABILITY_ARRAY= new float[PROBLEM_SIZE];
    
    // ==================================================================================
    //4. Constrained EDA execution
    
    if (VERBOSE)
        cout<<"4. Running Constrained EDA..."<<endl;
    int iteration=0;
    while (EVALUATIONS<MAX_EVALUATIONS){
        
        // 4.1. Learning
        //cout<<"Learning..."<<endl;
        Learn(POP,SEL_SIZE);
        
        // 4.2. Sampling
        //cout<<"Sampling..."<<endl;
        if ((EVALUATIONS+OFF_SIZE)<MAX_EVALUATIONS){
            EVALUATIONS+= Sample(POP, OFF_SIZE);
        }
        else{
            EVALUATIONS+= Sample(POP, (int)(MAX_EVALUATIONS-EVALUATIONS));
        }
        
        // 4.3. Update indicators and print logs.
        if (POP->SortPopulation(BEST)==true)
        {
            CONVERGENCE_EVALUATIONS=EVALUATIONS;
#ifdef PRINT_LOG
            cout<<"ITER: "<<iteration<<" , BS: "<<BEST->m_value<<" , EV: "<<EVALUATIONS<<" , REM: "<<MAX_EVALUATIONS-EVALUATIONS<<endl;
#endif
        }
        iteration++;
    }
    
    //5. Calculate consumed time and write results in file.
    gettimeofday(&tim, NULL);
    double t2=tim.tv_sec+(tim.tv_usec/1000000.0);
    cout<<"Final score: "<<BEST->m_value<<endl;
    cout<<"Time spent: "<<t2-t1<<endl;
    cout<<"Solution: "; PrintArray(BEST->m_solution, BEST->m_size);
    
    #ifndef KALIMERO
    FILE * test= fopen("/Users/Josu/Desktop/Lattice/results.csv","r");
    FILE * result_file= fopen("/Users/Josu/Desktop/Lattice/results.csv","a+");
    if (test==NULL){
        fprintf(result_file,"\"Instance\";\"Repetition\";\"Algorithm\";\"Fitness\";\"Time\"\n");
    }
    fprintf(result_file,"\"%s\";%d;\"%s\";%ld;%.3f\n",INSTANCE_FILENAME,SEED,"UMDA",BEST->m_value,t2-t1);
    fclose(result_file);
    fclose(test);
    #endif
    
#ifdef KALIMERO
    //In Kalimero
    FILE * result_file= fopen("./scratch_results.csv","w");
//    fprintf(result_file,"\"Instance\";\"Repetition\";\"Algorithm\";\"Fitness\";\"Time\"\n");
    fprintf(result_file,"\"%s\";%d;\"%s\";%ld;%.3f\n",INSTANCE_FILENAME,SEED,"UMDA_new",BEST->m_value,t2-t1);
    fclose(result_file);
#endif
    
    //6. Delete structures
    delete PROBABILITY_ARRAY;
    delete POP;
    delete BEST;
    return 0;
}

/*
 * Generates a random binary solution of size 'n' in the given array with equal number of 0s and 1s.
 */
void GenerateRandomBinaryBalanced(int * solution, long n)
{
    std::fill_n(solution,n,0);
    int i=0; // In order to avoid symmetry in the problem, we fix in the first position always 0.
    int pos;
    while (i<(n/2)){
        pos=1+(rand()%(n-1));// In order to avoid symmetry in the problem, we fix in the first position always 0.
        if (solution[pos]==0){
            solution[pos]=1;
            i++;
        }
    }
    
}

/*
 * Given a population of solutions, it calculates the parameters of the probabilistic model.
 */
void Learn(CPopulation * pop, int num_solutions_to_learn){
    
    //auxiliary variables
    long i,j;
    int * solution;
    
    //clear probability array.
    std::fill_n(PROBABILITY_ARRAY,PROBLEM_SIZE,0);
    

    //estimate parameters of probability matrix.
    for (i=0;i<num_solutions_to_learn;i++){
        solution=pop->m_individuals[i]->m_solution;
        for (j=0;j<PROBLEM_SIZE;j++){
            PROBABILITY_ARRAY[j]+=(solution[j]==0);
        }
    }
    for (j=0;j<PROBLEM_SIZE;j++){
        PROBABILITY_ARRAY[j]=(PROBABILITY_ARRAY[j]+1)/(num_solutions_to_learn+1);
    }
    
  }

/*
 * Samples new solutions from the probabilistic model. Includes a normalization technique to guarantee the validity of solutions.
 */
int Sample(CPopulation * pop, int num_samples){
    
    int i;
    long j;
    int * solution= new int[PROBLEM_SIZE];
    float * probs= new float[PROBLEM_SIZE];
    memcpy(probs, PROBABILITY_ARRAY, sizeof(float)*PROBLEM_SIZE);
    double val;
    int ones,zeros;
    long half=PROBLEM_SIZE/2;
      for (i=0;i<num_samples;i++){
        solution[0]=0;//in the first position always 0.
        //cout<<"i: "<<i<<endl;
        ones=0;
        zeros=1;
        for (j=1;j<PROBLEM_SIZE && ones<half && zeros<half ;j++){
            val = ((double)rand() / ((double)RAND_MAX + 1 ) );
            solution[j]= (val>probs[j]);
            ones+=solution[j];
            zeros+=(solution[j]==0);
        }
        //  printf("j: %ld, zeros: %d, ones: %d\n",j,zeros,ones);
        if (ones<half){
            for (;j<PROBLEM_SIZE;j++){
                solution[j]=1;
            }
        }
        else if (zeros<half){
            for (;j<PROBLEM_SIZE;j++){
                solution[j]=0;
            }
        }
         // PrintArray(solution, PROBLEM_SIZE);
        /*  int sum=0;
          for (j=0;j<PROBLEM_SIZE;j++){
              sum+=solution[j];
          }
          if (sum!=half){
               cout<<"Solution is NOT valid!"<<endl;
              exit(1);
          }*/
          
        //save new solution in the population
        pop->SetToPopulation(solution, pop->m_pop_size+i, PROBLEM->Evaluate( solution));
    }

    
    delete [] probs;
    delete [] solution;
    return num_samples;
}


/*
 * Prints in the standard output the 'size' elements of the given array..
 */
void PrintArray(int * array, long size)
{
    for (long i=0;i<size;i++){
        cout<<array[i]<<" ";
    }
    cout<<" "<<endl;
}

/*
 * Prints in the standard output the 'size' elements of the given array..
 */
void PrintArray(float * array, long size)
{
    for (long i=0;i<size;i++){
        cout<<array[i]<<" ";
    }
    cout<<" "<<endl;
}

/*
 * Prints in the standard output given matrix.
 */
void PrintMatrix(float** matrix, long length, int length2)
{
    int i,j;
    for (i=0;i<length;i++)
    {
        for (j=0;j<length2;j++)
        {
            printf("%.2f\t",matrix[i][j]);
        }
        printf("\n");
    }
    printf("\n");
}
